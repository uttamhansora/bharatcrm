{
    'name': 'BharatPlus Subscription (Stripe Billing)',
    'version': '19.0.1.1.0',
    'summary': '1-month free trial, then ₹400 per team member per month, billed by Stripe recurring subscriptions',
    'description': """
SaaS billing for BharatPlus CRM
===============================
* Business signup: a new customer gets their own company and a Company
  Administrator user (not an Odoo system admin).
* One Stripe Customer + one Stripe Subscription per company (res.company).
* Subscription quantity = number of active internal users of the company
  (server-side count, kept in sync on every user create/write/unlink).
* 1 month free trial handled by Stripe (trial_end), then ₹400/member/month.
* Company administrators invite / deactivate team members (CRM > Configuration).
* Stripe webhooks (signature-verified, idempotent) keep Odoo in sync.
* Billing page: Settings > Subscription (system admins) and
  CRM > Configuration > Subscription (company administrators).
""",
    'author': 'Bharatplus',
    'website': 'https://www.bharatplus.co',
    'license': 'LGPL-3',
    'category': 'Sales/CRM',
    'depends': ['base_setup', 'mail', 'auth_signup', 'sales_team', 'crm', 'account', 'product'],
    'external_dependencies': {'python': ['stripe']},
    'data': [
        'security/groups.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/currency_data.xml',
        'data/cron.xml',
        'views/subscription_views.xml',
        'views/team_views.xml',
        'views/res_config_settings_views.xml',
        'views/auth_signup_templates.xml',
    ],
    'post_init_hook': 'post_init_hook',
    'installable': True,
    'application': False,
    'auto_install': False,
}
