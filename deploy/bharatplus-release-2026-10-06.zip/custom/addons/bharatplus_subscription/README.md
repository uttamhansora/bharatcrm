# BharatPlus Subscription (Stripe Billing)

SaaS billing for BharatPlus CRM: **1 month free trial**, then **₹400 INR per team
member per month**, billed by Stripe recurring subscriptions.

## How it maps onto the application

| Concept | Odoo object |
|---|---|
| Customer / account | `res.company` (one subscription per company) |
| Team member (billable) | active internal `res.users` of that company (`share = False`, not the system bot) |
| Deactivated member | archived user (`active = False`) → not billed |
| Portal / public users | never billed |
| Subscription | `bharatplus.subscription` |
| Webhook log | `bharatplus.stripe.event` (unique Stripe event id → idempotent) |

Quantity is always computed server-side from the users table and pushed to
Stripe in the same transaction as the user change. If Stripe rejects the update
the user change is rolled back.

## Configuration

Settings → **BharatPlus Subscription**, or environment variables (take precedence):

```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_ID=price_...
```

Use `sk_live_…` keys for live mode; nothing else changes.

## Stripe Dashboard setup

1. Create the product/price with the **Create Product & Price in Stripe** button
   (product "BharatPlus CRM Team Member", ₹400/month recurring = 40 000 paise) or
   create it manually and paste the `price_...` id.
2. Developers → Webhooks → add endpoint `https://<your-host>/bharatplus/stripe/webhook`
   with events: `customer.subscription.created`, `customer.subscription.updated`,
   `customer.subscription.deleted`, `customer.subscription.trial_will_end`,
   `invoice.paid`, `invoice.payment_failed`, `checkout.session.completed`.
   Paste the signing secret into the settings.
3. Settings → Billing → Customer portal: enable the portal (payment method update,
   invoice history). Cancellation is done from BharatPlus (cancel at period end).

## Local testing with Stripe CLI

```
stripe listen --forward-to http://127.0.0.1:8069/bharatplus/stripe/webhook
```

Use the printed `whsec_…` as the webhook secret. Test card: `4242 4242 4242 4242`.
Use `stripe trigger invoice.payment_failed` etc. or the Dashboard test clock to
fast-forward the trial.

## Automated tests

```
python odoo-bin -c odoo.conf -d <db> -u bharatplus_subscription --test-enable --test-tags /bharatplus_subscription --stop-after-init
```
