import json
import logging

import psycopg2

from odoo import api, fields, models

from .stripe_client import as_dict

_logger = logging.getLogger(__name__)


class BharatplusStripeEvent(models.Model):
    """Log of received Stripe webhook events. The unique event id makes
    processing idempotent: a redelivered event is acknowledged, not re-applied."""
    _name = 'bharatplus.stripe.event'
    _description = 'Stripe Webhook Event'
    _order = 'id desc'
    _rec_name = 'event_id'

    event_id = fields.Char(required=True, readonly=True, index=True)
    event_type = fields.Char(readonly=True)
    livemode = fields.Boolean(readonly=True)
    subscription_id = fields.Many2one('bharatplus.subscription', readonly=True, ondelete='set null')
    processed = fields.Boolean(readonly=True)
    error = fields.Text(readonly=True)
    payload = fields.Text(readonly=True)

    _event_id_uniq = models.Constraint('UNIQUE (event_id)', 'This Stripe event was already received.')

    @api.model
    def _register_event(self, event):
        """Return (record, is_new). Concurrent deliveries of the same event are
        serialised by the unique constraint."""
        event = as_dict(event)
        existing = self.search([('event_id', '=', event['id'])], limit=1)
        if existing:
            return existing, False
        try:
            with self.env.cr.savepoint():
                record = self.create({
                    'event_id': event['id'],
                    'event_type': event['type'],
                    'livemode': bool(event.get('livemode')),
                    'payload': json.dumps(event.get('data', {}).get('object', {}), default=str)[:20000],
                })
                return record, True
        except psycopg2.IntegrityError:
            return self.search([('event_id', '=', event['id'])], limit=1), False

    # ------------------------------------------------------------------
    def _find_subscription(self, obj):
        Subscription = self.env['bharatplus.subscription'].sudo()
        sub_id = obj.get('id') if obj.get('object') == 'subscription' else None
        if sub_id:
            sub = Subscription.search([('stripe_subscription_id', '=', sub_id)], limit=1)
            if sub:
                return sub
        customer = obj.get('customer')
        customer_id = customer if isinstance(customer, str) else (customer or {}).get('id')
        if customer_id:
            sub = Subscription.search([('stripe_customer_id', '=', customer_id)], limit=1)
            if sub:
                return sub
        company_id = (obj.get('metadata') or {}).get('bharatplus_company_id')
        if company_id and company_id.isdigit():
            return Subscription.search([('company_id', '=', int(company_id))], limit=1)
        return Subscription

    @staticmethod
    def _invoice_subscription_id(invoice):
        details = ((invoice.get('parent') or {}).get('subscription_details') or {})
        sub = details.get('subscription') or invoice.get('subscription')
        return sub if isinstance(sub, str) else (sub or {}).get('id')

    def _process(self, event):
        """Apply one verified Stripe event to the matching subscription."""
        self.ensure_one()
        event = as_dict(event)
        event_type = event['type']
        obj = event['data']['object']
        Subscription = self.env['bharatplus.subscription'].sudo()

        if event_type.startswith('customer.subscription.'):
            sub = self._find_subscription(obj)
            if not sub:
                _logger.info("Stripe event %s ignored: no matching subscription", event['id'])
                return
            # Only adopt subscriptions created through this module (or a re-created one for the same customer)
            if sub.stripe_subscription_id and sub.stripe_subscription_id != obj['id'] and sub.state not in ('canceled', 'incomplete_expired'):
                _logger.warning("Stripe event %s for %s ignored: company already linked to %s",
                                event['id'], obj['id'], sub.stripe_subscription_id)
                return
            previous_state = sub.state
            sub._apply_stripe_subscription(obj)
            self.subscription_id = sub
            if event_type == 'customer.subscription.trial_will_end':
                sub._on_trial_will_end()
            elif event_type == 'customer.subscription.deleted':
                sub.message_post(body="Subscription ended in Stripe.")
            elif event_type == 'customer.subscription.updated':
                if previous_state != sub.state:
                    sub.message_post(body=f"Subscription status changed to {dict(sub._fields['state'].selection)[sub.state]}.")
                # Reconcile: Stripe's quantity must always equal the real member count
                sub._sync_quantity(raise_on_error=False)

        elif event_type in ('invoice.paid', 'invoice.payment_failed'):
            sub_id = self._invoice_subscription_id(obj)
            sub = Subscription.search([('stripe_subscription_id', '=', sub_id)], limit=1) if sub_id else Subscription
            if not sub:
                sub = self._find_subscription(obj)
            if not sub:
                return
            self.subscription_id = sub
            sub._on_invoice(obj, paid=(event_type == 'invoice.paid'))

        elif event_type == 'checkout.session.completed':
            sub = self._find_subscription(obj)
            if not sub:
                return
            self.subscription_id = sub
            sub._handle_checkout_session(obj)
