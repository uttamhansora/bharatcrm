from odoo import api, models


class ResPartner(models.Model):
    """Contacts created by a customer's team belong to that customer's company,
    so they are never visible to another customer sharing the database."""
    _inherit = 'res.partner'

    @api.model_create_multi
    def create(self, vals_list):
        if not self.env.su and not self.env.user.has_group('base.group_system'):
            for vals in vals_list:
                if not vals.get('company_id'):
                    vals['company_id'] = self.env.company.id
        return super().create(vals_list)
