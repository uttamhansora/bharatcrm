import logging
from datetime import datetime, timezone

import stripe
from dateutil.relativedelta import relativedelta

from odoo import SUPERUSER_ID, _, api, fields, models
from odoo.exceptions import AccessError, UserError

from .stripe_client import as_dict, get_client, get_setting, stripe_error_message

_logger = logging.getLogger(__name__)

TRIAL_MONTHS = 1
DEFAULT_UNIT_AMOUNT = 400.0   # INR per team member per month
STRIPE_CURRENCY = 'inr'       # INR has 2 decimals on Stripe: amounts are in paise (₹400 = 40000)

# Stripe subscription statuses, mapped 1:1 (plus our local "draft" = not started)
STATES = [
    ('draft', 'Not Started'),
    ('trialing', 'Trialing'),
    ('active', 'Active'),
    ('past_due', 'Past Due'),
    ('unpaid', 'Unpaid'),
    ('paused', 'Paused'),
    ('incomplete', 'Incomplete'),
    ('incomplete_expired', 'Incomplete (Expired)'),
    ('canceled', 'Canceled'),
]
# States in which the Stripe quantity must follow the member count
SYNCABLE_STATES = ('trialing', 'active', 'past_due', 'unpaid', 'paused', 'incomplete')
ENDED_STATES = ('canceled', 'incomplete_expired')


def ts_to_dt(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc).replace(tzinfo=None) if ts else False


def dt_to_ts(dt):
    return int(dt.replace(tzinfo=timezone.utc).timestamp())


def _id_of(value):
    """Stripe fields may hold an id or an expanded object."""
    if not value:
        return False
    return value if isinstance(value, str) else value.get('id')


class BharatplusSubscription(models.Model):
    _name = 'bharatplus.subscription'
    _description = 'BharatPlus CRM Subscription'
    _inherit = ['mail.thread']
    _order = 'id'

    name = fields.Char(compute='_compute_name')
    company_id = fields.Many2one(
        'res.company', string='Company', required=True, index=True, ondelete='cascade',
        default=lambda self: self.env.company)
    currency_id = fields.Many2one(
        'res.currency', readonly=True,
        default=lambda self: self.env.ref('base.INR', raise_if_not_found=False))
    unit_amount = fields.Monetary(
        string='Price per Team Member / Month', currency_field='currency_id',
        default=DEFAULT_UNIT_AMOUNT, readonly=True)
    member_count = fields.Integer(string='Current Team Members', compute='_compute_member_count')
    quantity = fields.Integer(string='Billed Team Members (Stripe)', readonly=True, tracking=True)
    monthly_amount = fields.Monetary(
        string='Current Monthly Amount', currency_field='currency_id', compute='_compute_monthly_amount')
    state = fields.Selection(STATES, string='Subscription Status', default='draft', readonly=True, tracking=True)

    stripe_customer_id = fields.Char(readonly=True, copy=False)
    stripe_subscription_id = fields.Char(readonly=True, copy=False)
    stripe_subscription_item_id = fields.Char(readonly=True, copy=False)
    stripe_price_id = fields.Char(readonly=True, copy=False)
    stripe_payment_method_id = fields.Char(readonly=True, copy=False)
    stripe_livemode = fields.Boolean(string='Live Mode', readonly=True)

    trial_used = fields.Boolean(readonly=True, help='A free trial has already been granted to this company.')
    trial_start = fields.Datetime(readonly=True)
    trial_end = fields.Datetime(string='Trial Ends', readonly=True)
    current_period_start = fields.Datetime(readonly=True)
    current_period_end = fields.Datetime(string='Current Period Ends', readonly=True)
    next_billing_date = fields.Datetime(compute='_compute_next_billing_date')
    cancel_at_period_end = fields.Boolean(readonly=True, tracking=True)
    cancel_at = fields.Datetime(readonly=True)
    canceled_at = fields.Datetime(readonly=True)

    payment_method_set = fields.Boolean(string='Payment Method on File', readonly=True)
    payment_method_label = fields.Char(string='Payment Method', readonly=True)
    last_payment_status = fields.Selection(
        [('paid', 'Paid'), ('failed', 'Failed')], string='Last Payment', readonly=True, tracking=True)
    last_invoice_url = fields.Char(string='Last Invoice', readonly=True)
    last_invoice_date = fields.Datetime(readonly=True)
    last_sync = fields.Datetime(string='Last Stripe Sync', readonly=True)
    last_error = fields.Text(readonly=True)
    is_stripe_configured = fields.Boolean(compute='_compute_is_stripe_configured')

    _company_uniq = models.Constraint('UNIQUE (company_id)', 'A company can only have one subscription.')

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends('company_id.name')
    def _compute_name(self):
        for sub in self:
            sub.name = _("%s – BharatPlus CRM Subscription", sub.company_id.name or '')

    def _get_billable_users(self):
        """Team members that are billed: active internal users of the company.
        Portal/public users and the system bot are never billed."""
        self.ensure_one()
        return self.env['res.users'].sudo().search([
            ('company_id', '=', self.company_id.id),
            ('active', '=', True),
            ('share', '=', False),
            ('id', '!=', SUPERUSER_ID),
        ])

    def _billable_quantity(self):
        """Quantity sent to Stripe. A company always has at least one user
        (its administrator), so the quantity is never below 1."""
        return max(len(self._get_billable_users()), 1)

    @api.depends('company_id')
    def _compute_member_count(self):
        for sub in self:
            sub.member_count = len(sub._get_billable_users()) if sub.company_id else 0

    @api.depends('member_count', 'unit_amount')
    def _compute_monthly_amount(self):
        for sub in self:
            sub.monthly_amount = max(sub.member_count, 1) * sub.unit_amount if sub.company_id else 0

    @api.depends('state', 'trial_end', 'current_period_end', 'cancel_at_period_end')
    def _compute_next_billing_date(self):
        for sub in self:
            if sub.cancel_at_period_end:
                sub.next_billing_date = False   # ends at period/trial end, nothing more is billed
            elif sub.state == 'trialing':
                sub.next_billing_date = sub.trial_end
            elif sub.state in ('active', 'past_due', 'unpaid'):
                sub.next_billing_date = sub.current_period_end
            else:
                sub.next_billing_date = False

    def _compute_is_stripe_configured(self):
        configured = bool(get_setting(self.env, 'stripe_secret_key') and get_setting(self.env, 'stripe_price_id'))
        for sub in self:
            sub.is_stripe_configured = configured

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @api.model
    def _get_for_company(self, company, create=True):
        sub = self.sudo().search([('company_id', '=', company.id)], limit=1)
        if not sub and create:
            sub = self.sudo().create({'company_id': company.id})
        return sub

    @api.model
    def action_open_my_subscription(self):
        """Open the subscription of the current company (Settings > Subscription)."""
        if not self.env.user._is_bharatplus_manager():
            raise AccessError(_("Only administrators can manage the subscription."))
        sub = self._get_for_company(self.env.company)
        return {
            'type': 'ir.actions.act_window',
            'name': _('Subscription'),
            'res_model': 'bharatplus.subscription',
            'res_id': sub.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def _check_manage_rights(self):
        for sub in self:
            if not self.env.user._is_bharatplus_manager() or sub.company_id not in self.env.user.company_ids:
                raise AccessError(_("You are not allowed to manage the subscription of %s.", sub.company_id.name))

    def _base_url(self):
        return (self.env['ir.config_parameter'].sudo().get_param('web.base.url') or '').rstrip('/')

    def _billing_page_url(self):
        return f"{self._base_url()}/crm/action-bharatplus_subscription.action_open_subscription"

    def _stripe_metadata(self):
        return {'bharatplus_company_id': str(self.company_id.id), 'bharatplus_db': self.env.cr.dbname}

    def _get_billing_email(self):
        return self.company_id.email or self.env.user.email or ''

    def _admin_partners(self):
        """Partners of the company's administrators (notified about billing events)."""
        admins = self.env['res.users'].sudo().search([
            ('company_id', '=', self.company_id.id), ('active', '=', True), ('share', '=', False),
            ('id', '!=', SUPERUSER_ID),
        ]).filtered(lambda u: u._is_bharatplus_manager())
        return admins.partner_id

    def _notify_admins(self, body):
        self.ensure_one()
        self.message_post(body=body, partner_ids=self._admin_partners().ids, subtype_xmlid='mail.mt_comment')

    # ------------------------------------------------------------------
    # Stripe objects -> Odoo
    # ------------------------------------------------------------------
    def _apply_stripe_subscription(self, sub):
        """Copy the state of a Stripe Subscription object onto this record.
        Stripe is the source of truth for status, periods, trial and cancellation."""
        self.ensure_one()
        sub = as_dict(sub)
        items = (sub.get('items') or {}).get('data') or []
        item = items[0] if items else None
        vals = {
            'stripe_subscription_id': sub['id'],
            'stripe_customer_id': _id_of(sub.get('customer')) or self.stripe_customer_id,
            'stripe_livemode': bool(sub.get('livemode')),
            'state': sub['status'],
            'trial_start': ts_to_dt(sub.get('trial_start')),
            'trial_end': ts_to_dt(sub.get('trial_end')),
            'cancel_at_period_end': bool(sub.get('cancel_at_period_end')),
            'cancel_at': ts_to_dt(sub.get('cancel_at')),
            'canceled_at': ts_to_dt(sub.get('canceled_at')),
            'last_sync': fields.Datetime.now(),
            'last_error': False,
        }
        if sub.get('trial_start'):
            vals['trial_used'] = True
        if item:
            price = item.get('price') or {}
            vals.update({
                'stripe_subscription_item_id': item['id'],
                'quantity': item.get('quantity') or 0,
                'stripe_price_id': _id_of(price),
                # API 2025-03-31+ moved the billing period onto the subscription item
                'current_period_start': ts_to_dt(item.get('current_period_start') or sub.get('current_period_start')),
                'current_period_end': ts_to_dt(item.get('current_period_end') or sub.get('current_period_end')),
            })
            if isinstance(price, dict) and price.get('unit_amount') is not None:
                vals['unit_amount'] = price['unit_amount'] / 100.0   # paise -> rupees
        pm_id = _id_of(sub.get('default_payment_method'))
        if pm_id:
            vals.update({'stripe_payment_method_id': pm_id, 'payment_method_set': True})
        self.write(vals)

    def _apply_payment_method(self, client, pm_id):
        """Store a display label for the customer's default payment method."""
        try:
            pm = as_dict(client.v1.payment_methods.retrieve(pm_id))
            card = pm.get('card') or {}
            label = f"{(card.get('brand') or pm.get('type') or '').title()} •••• {card.get('last4')}" if card else (pm.get('type') or '').title()
        except stripe.StripeError:
            label = pm_id
        self.write({'stripe_payment_method_id': pm_id, 'payment_method_set': True, 'payment_method_label': label})

    # ------------------------------------------------------------------
    # Stripe customer / subscription lifecycle
    # ------------------------------------------------------------------
    def _ensure_stripe_customer(self, client):
        """One Stripe Customer per company; never create a duplicate."""
        self.ensure_one()
        if self.stripe_customer_id:
            return self.stripe_customer_id
        params = {'name': self.company_id.name, 'metadata': self._stripe_metadata()}
        email = self._get_billing_email()
        if email:
            params['email'] = email
        customer = as_dict(client.v1.customers.create(params=params))
        self.write({'stripe_customer_id': customer['id']})
        return customer['id']

    def action_start_subscription(self):
        """Create the Stripe subscription: ₹400 × members / month, 1 month free
        for a new customer. Trial starts now, Stripe bills automatically after it."""
        self.ensure_one()
        self._check_manage_rights()
        if self.stripe_subscription_id and self.state not in ENDED_STATES:
            raise UserError(_("This company already has a running Stripe subscription."))
        price_id = get_setting(self.env, 'stripe_price_id')
        if not price_id:
            raise UserError(_("No Stripe price is configured. Open Settings > BharatPlus Subscription first."))
        client = get_client(self.env)
        quantity = self._billable_quantity()
        params = {
            'items': [{'price': price_id, 'quantity': quantity}],
            'collection_method': 'charge_automatically',
            'payment_settings': {'save_default_payment_method': 'on_subscription'},
            'metadata': self._stripe_metadata(),
        }
        with_trial = not self.trial_used
        if with_trial:
            # explicit UTC: independent of the server's local time zone
            trial_end = datetime.now(timezone.utc).replace(tzinfo=None) + relativedelta(months=TRIAL_MONTHS)
            params['trial_end'] = dt_to_ts(trial_end)
            # No card needed to start the trial; if none is added by the end of
            # the trial, Stripe pauses the subscription instead of failing charges.
            params['trial_settings'] = {'end_behavior': {'missing_payment_method': 'pause'}}
        try:
            params['customer'] = self._ensure_stripe_customer(client)
            sub = client.v1.subscriptions.create(params=params)
        except stripe.StripeError as e:
            raise UserError(_("Stripe could not create the subscription: %s", stripe_error_message(e)))
        self._apply_stripe_subscription(sub)
        if with_trial:
            self.write({'trial_used': True})
            self.message_post(body=_(
                "Subscription started with a %(months)s-month free trial for %(qty)s team member(s). "
                "Trial ends on %(date)s.",
                months=TRIAL_MONTHS, qty=quantity, date=fields.Datetime.to_string(self.trial_end)))
        else:
            self.message_post(body=_("Subscription restarted for %s team member(s) (no trial).", quantity))
        return True

    def _sync_quantity(self, raise_on_error=True):
        """Push the real billable member count to Stripe. Idempotent: it only
        calls Stripe when the stored quantity differs from the actual count."""
        for sub in self:
            if not sub.stripe_subscription_id or not sub.stripe_subscription_item_id or sub.state not in SYNCABLE_STATES:
                continue
            quantity = sub._billable_quantity()
            if quantity == sub.quantity:
                continue
            try:
                client = get_client(sub.env)
                result = client.v1.subscriptions.update(sub.stripe_subscription_id, params={
                    'items': [{'id': sub.stripe_subscription_item_id, 'quantity': quantity}],
                    'proration_behavior': 'create_prorations',
                })
            except stripe.StripeError as e:
                message = stripe_error_message(e)
                _logger.warning("Stripe quantity sync failed for %s: %s", sub.company_id.name, message)
                if raise_on_error:
                    raise UserError(_(
                        "The team member change could not be synchronised with Stripe billing, "
                        "so it has not been saved. Please try again.\n\nStripe: %s", message))
                sub.write({'last_error': message})
                continue
            sub._apply_stripe_subscription(result)
            sub.message_post(body=_("Billed team members updated to %s.", quantity))

    def _on_members_changed(self):
        """Hook called by res.users after a change that may affect the count."""
        self.with_context(skip_member_sync=True)._sync_quantity(raise_on_error=True)

    # ------------------------------------------------------------------
    # Buttons
    # ------------------------------------------------------------------
    def action_add_payment_method(self):
        """Stripe Checkout (setup mode): the card is collected and stored by Stripe only."""
        self.ensure_one()
        self._check_manage_rights()
        client = get_client(self.env)
        try:
            customer_id = self._ensure_stripe_customer(client)
            session = as_dict(client.v1.checkout.sessions.create(params={
                'mode': 'setup',
                'customer': customer_id,
                'currency': STRIPE_CURRENCY,
                'payment_method_types': ['card'],
                'success_url': f"{self._base_url()}/bharatplus/billing/return?session_id={{CHECKOUT_SESSION_ID}}",
                'cancel_url': f"{self._base_url()}/bharatplus/billing/return",
                'metadata': {**self._stripe_metadata(), 'bharatplus_subscription_id': str(self.id)},
            }))
        except stripe.StripeError as e:
            raise UserError(_("Stripe error: %s", stripe_error_message(e)))
        return {'type': 'ir.actions.act_url', 'url': session['url'], 'target': 'self'}

    def _handle_checkout_session(self, session, client=None):
        """Attach the payment method collected by Checkout as default for the
        customer and the subscription. Idempotent (return URL + webhook)."""
        self.ensure_one()
        session = as_dict(session)
        if session.get('mode') != 'setup' or session.get('status') != 'complete':
            return False
        if _id_of(session.get('customer')) != self.stripe_customer_id:
            return False
        client = client or get_client(self.env)
        setup_intent = session.get('setup_intent')
        if isinstance(setup_intent, str):
            setup_intent = client.v1.setup_intents.retrieve(setup_intent)
        setup_intent = as_dict(setup_intent)
        pm_id = _id_of((setup_intent or {}).get('payment_method'))
        if not pm_id or pm_id == self.stripe_payment_method_id:
            return False
        client.v1.customers.update(self.stripe_customer_id, params={
            'invoice_settings': {'default_payment_method': pm_id}})
        if self.stripe_subscription_id and self.state not in ENDED_STATES:
            if self.state == 'paused':
                # Trial ended without a card: resume billing now that there is one
                sub = client.v1.subscriptions.resume(self.stripe_subscription_id, params={
                    'billing_cycle_anchor': 'now', 'proration_behavior': 'create_prorations'})
                sub = client.v1.subscriptions.update(sub['id'], params={'default_payment_method': pm_id})
            else:
                sub = client.v1.subscriptions.update(self.stripe_subscription_id, params={
                    'default_payment_method': pm_id})
            self._apply_stripe_subscription(sub)
        self._apply_payment_method(client, pm_id)
        self.message_post(body=_("Payment method added: %s", self.payment_method_label))
        return True

    def action_manage_billing(self):
        """Stripe Billing Portal: invoices, payment methods, billing details."""
        self.ensure_one()
        self._check_manage_rights()
        client = get_client(self.env)
        try:
            customer_id = self._ensure_stripe_customer(client)
            session = as_dict(client.v1.billing_portal.sessions.create(params={
                'customer': customer_id, 'return_url': self._billing_page_url()}))
        except stripe.StripeError as e:
            raise UserError(_("Stripe error: %s", stripe_error_message(e)))
        return {'type': 'ir.actions.act_url', 'url': session['url'], 'target': 'self'}

    def action_cancel(self):
        """Cancel at the end of the current period; data is kept."""
        self.ensure_one()
        self._check_manage_rights()
        if not self.stripe_subscription_id or self.state in ENDED_STATES:
            raise UserError(_("There is no running subscription to cancel."))
        client = get_client(self.env)
        try:
            sub = client.v1.subscriptions.update(self.stripe_subscription_id, params={'cancel_at_period_end': True})
        except stripe.StripeError as e:
            raise UserError(_("Stripe error: %s", stripe_error_message(e)))
        self._apply_stripe_subscription(sub)
        until = self.current_period_end or self.trial_end
        self.message_post(body=_("Subscription cancellation scheduled. It remains active until %s.",
                                 fields.Datetime.to_string(until) if until else '-'))
        return True

    def action_resume(self):
        """Undo a scheduled cancellation, or resume a subscription paused after the trial."""
        self.ensure_one()
        self._check_manage_rights()
        if not self.stripe_subscription_id:
            raise UserError(_("There is no subscription to resume."))
        client = get_client(self.env)
        try:
            if self.state == 'paused':
                if not self.payment_method_set:
                    raise UserError(_("Add a payment method first, then the subscription resumes automatically."))
                sub = client.v1.subscriptions.resume(self.stripe_subscription_id, params={
                    'billing_cycle_anchor': 'now', 'proration_behavior': 'create_prorations'})
            elif self.cancel_at_period_end:
                sub = client.v1.subscriptions.update(self.stripe_subscription_id, params={'cancel_at_period_end': False})
            else:
                raise UserError(_("The subscription is not scheduled for cancellation."))
        except stripe.StripeError as e:
            raise UserError(_("Stripe error: %s", stripe_error_message(e)))
        self._apply_stripe_subscription(sub)
        self.message_post(body=_("Subscription resumed."))
        return True

    def action_sync(self):
        self.ensure_one()
        self._check_manage_rights()
        self._sync_from_stripe(raise_on_error=True)
        self._sync_quantity(raise_on_error=True)
        return True

    def _sync_from_stripe(self, raise_on_error=False):
        """Pull the current subscription + default payment method from Stripe."""
        for sub in self:
            if not sub.stripe_subscription_id:
                continue
            try:
                client = get_client(sub.env)
                stripe_sub = as_dict(client.v1.subscriptions.retrieve(sub.stripe_subscription_id))
                sub._apply_stripe_subscription(stripe_sub)
                customer = as_dict(client.v1.customers.retrieve(sub.stripe_customer_id))
                pm_id = _id_of((customer.get('invoice_settings') or {}).get('default_payment_method')) \
                    or _id_of(stripe_sub.get('default_payment_method'))
                if pm_id and pm_id != sub.stripe_payment_method_id:
                    sub._apply_payment_method(client, pm_id)
                elif not pm_id and sub.payment_method_set:
                    sub.write({'payment_method_set': False, 'payment_method_label': False,
                               'stripe_payment_method_id': False})
            except stripe.StripeError as e:
                message = stripe_error_message(e)
                if raise_on_error:
                    raise UserError(_("Stripe error: %s", message))
                sub.write({'last_error': message})

    @api.model
    def _cron_reconcile(self):
        """Safety net behind the webhooks: daily reconciliation of state and quantity."""
        for sub in self.sudo().search([('stripe_subscription_id', '!=', False)]):
            try:
                with self.env.cr.savepoint():
                    sub._sync_from_stripe(raise_on_error=False)
                    sub._sync_quantity(raise_on_error=False)
            except Exception as e:  # noqa: BLE001 - one bad record must not stop the cron
                _logger.exception("Subscription reconciliation failed for %s", sub.company_id.name)
                sub.write({'last_error': str(e)})

    # ------------------------------------------------------------------
    # Webhook business events
    # ------------------------------------------------------------------
    def _on_trial_will_end(self):
        self.ensure_one()
        body = _("Your free trial ends on %s. ", fields.Datetime.to_string(self.trial_end))
        if self.payment_method_set:
            body += _("Billing of ₹%s per team member per month starts automatically on that date.", int(self.unit_amount))
        else:
            body += _("Add a payment method before then to keep using BharatPlus CRM without interruption.")
        self._notify_admins(body)

    def _on_invoice(self, invoice, paid):
        self.ensure_one()
        invoice = as_dict(invoice)
        amount = (invoice.get('amount_paid') if paid else invoice.get('amount_due')) or 0
        self.write({
            'last_payment_status': 'paid' if paid else 'failed',
            'last_invoice_url': invoice.get('hosted_invoice_url') or self.last_invoice_url,
            'last_invoice_date': ts_to_dt(invoice.get('created')),
        })
        if paid:
            self.message_post(body=_("Payment received: ₹%s.", f"{amount / 100:,.2f}"))
        else:
            self._notify_admins(_(
                "Payment of ₹%s failed. Please update your payment method under Settings > Subscription "
                "to avoid interruption of service.", f"{amount / 100:,.2f}"))
