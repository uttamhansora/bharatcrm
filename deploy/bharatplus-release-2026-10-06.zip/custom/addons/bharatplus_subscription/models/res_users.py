import logging

from odoo import SUPERUSER_ID, _, api, fields, models
from odoo.exceptions import AccessError, UserError

_logger = logging.getLogger(__name__)

COMPANY_ADMIN_GROUP = 'bharatplus_subscription.group_company_admin'
# Roles a company administrator may give to team members (nothing else can be granted)
TEAM_ROLES = {
    'sales_own': ('Salesperson (own documents)', ['sales_team.group_sale_salesman']),
    'sales_all': ('Salesperson (all documents)', ['sales_team.group_sale_salesman_all_leads']),
    'admin': ('Company Administrator', [COMPANY_ADMIN_GROUP]),
}
PRIVILEGED_GROUPS = ('base.group_system', 'base.group_erp_manager')


class ResUsers(models.Model):
    """Team members of a BharatPlus CRM customer are the internal users of its company.

    * Every change that can alter the billable member count is propagated to the
      Stripe subscription quantity in the same transaction (rollback on failure).
    * Business signup creates a new company + a Company Administrator user.
    * Company administrators manage their team through dedicated, sudo-backed
      actions; they never get write access on res.users themselves.
    """
    _inherit = 'res.users'

    _BILLING_FIELDS = {'active', 'company_id', 'group_ids', 'groups_id', 'share'}

    bharatplus_role = fields.Char(string='Team Role', compute='_compute_bharatplus_role')

    # ------------------------------------------------------------------
    # Roles
    # ------------------------------------------------------------------
    def _is_bharatplus_manager(self):
        """May manage the subscription and team of their company."""
        self.ensure_one()
        return self.has_group('base.group_system') or self.has_group(COMPANY_ADMIN_GROUP)

    def _compute_bharatplus_role(self):
        for user in self:
            if user.share:
                user.bharatplus_role = _('Portal')
            elif user.has_group('base.group_system'):
                user.bharatplus_role = _('System Administrator')
            elif user.has_group(COMPANY_ADMIN_GROUP):
                user.bharatplus_role = TEAM_ROLES['admin'][0]
            elif user.has_group('sales_team.group_sale_salesman_all_leads'):
                user.bharatplus_role = TEAM_ROLES['sales_all'][0]
            elif user.has_group('sales_team.group_sale_salesman'):
                user.bharatplus_role = TEAM_ROLES['sales_own'][0]
            else:
                user.bharatplus_role = _('User')

    # ------------------------------------------------------------------
    # Stripe quantity synchronisation
    # ------------------------------------------------------------------
    def _bharatplus_sync_billing(self, companies):
        if self.env.context.get('skip_member_sync') or not companies:
            return
        subscriptions = self.env['bharatplus.subscription'].sudo().search([
            ('company_id', 'in', companies.ids),
            ('stripe_subscription_id', '!=', False),
        ])
        if subscriptions:
            self.env.flush_all()   # make sure computed `share`/`active` are written before counting
            subscriptions._on_members_changed()

    def _bharatplus_check_privileges(self):
        """Defence in depth: a non-system writer can never produce a privileged
        user or move a user outside their own companies."""
        if self.env.su or self.env.user.has_group('base.group_system'):
            return
        for user in self:
            if any(user.has_group(group) for group in PRIVILEGED_GROUPS):
                raise AccessError(_("You are not allowed to grant administrator rights."))
            if user.company_ids - self.env.user.company_ids:
                raise AccessError(_("You are not allowed to manage users of other companies."))

    @api.model_create_multi
    def create(self, vals_list):
        users = super().create(vals_list)
        users._bharatplus_check_privileges()
        users._bharatplus_sync_billing(users.company_id)
        return users

    def write(self, vals):
        companies_before = self.company_id
        result = super().write(vals)
        if self._BILLING_FIELDS & set(vals):
            self._bharatplus_check_privileges()
            self._bharatplus_sync_billing(companies_before | self.company_id)
        return result

    def unlink(self):
        companies = self.company_id
        result = super().unlink()
        self.env['res.users']._bharatplus_sync_billing(companies)
        return result

    # ------------------------------------------------------------------
    # Business signup: new customer = new company + Company Administrator
    # ------------------------------------------------------------------
    @api.model
    def _signup_create_user(self, values):
        company_name = (values.pop('company_name', '') or '').strip()
        if values.get('partner_id') or not company_name:
            # invited user (token) or plain signup: standard behaviour (portal user)
            return super()._signup_create_user(values)
        if self._get_signup_invitation_scope() != 'b2c':
            raise UserError(_('Signup is not allowed for uninvited users'))
        return self._bharatplus_create_business(company_name, values)

    @api.model
    def _bharatplus_create_business(self, company_name, values):
        login = (values.get('login') or '').strip()
        if not login or not values.get('name'):
            raise UserError(_("Please fill in your name and email."))
        Users = self.sudo().with_context(active_test=False)
        if Users.search_count([('login', '=ilike', login)]):
            raise UserError(_("An account already exists for %s. Please log in instead.", login))

        company_vals = {'name': company_name, 'email': login}
        currency = self.env.ref('base.INR', raise_if_not_found=False)
        if currency:
            company_vals['currency_id'] = currency.id
        country = self.env.ref('base.in', raise_if_not_found=False)
        if country:
            company_vals['country_id'] = country.id
        company = self.env['res.company'].sudo().create(company_vals)

        user_vals = {
            'name': values['name'],
            'login': login,
            'email': login,
            'password': values.get('password'),
            'company_id': company.id,
            'company_ids': [(6, 0, [company.id])],
            'group_ids': [(6, 0, [self.env.ref(COMPANY_ADMIN_GROUP).id])],
        }
        if values.get('lang'):
            user_vals['lang'] = values['lang']
        user = Users.with_context(no_reset_password=True, skip_member_sync=True).create(user_vals)
        user.partner_id.sudo().write({'company_id': company.id})
        _logger.info("BharatPlus business signup: company %s (id %s), admin %s", company.name, company.id, login)
        return user

    # ------------------------------------------------------------------
    # Team management (buttons of the Team Members list)
    # ------------------------------------------------------------------
    def _bharatplus_check_team_admin(self):
        current = self.env.user
        if not current._is_bharatplus_manager():
            raise AccessError(_("Only a company administrator can manage team members."))
        for user in self:
            if user.share or user.id == SUPERUSER_ID or user.company_id not in current.company_ids:
                raise AccessError(_("You are not allowed to manage this user."))

    def action_bharatplus_deactivate(self):
        """Remove a member from the team: no access, no longer billed."""
        self._bharatplus_check_team_admin()
        for user in self:
            if user == self.env.user:
                raise UserError(_("You cannot deactivate your own account."))
            if user.has_group(COMPANY_ADMIN_GROUP):
                other_admins = self.sudo().search([
                    ('company_id', '=', user.company_id.id), ('active', '=', True), ('id', '!=', user.id),
                ]).filtered(lambda u: u.has_group(COMPANY_ADMIN_GROUP))
                if not other_admins:
                    raise UserError(_("%s is the last administrator of the company and cannot be deactivated.", user.name))
        self.sudo().write({'active': False})   # -> Stripe quantity decreases
        return True

    def action_bharatplus_reactivate(self):
        self._bharatplus_check_team_admin()
        self.sudo().write({'active': True})    # -> Stripe quantity increases
        return True
