from odoo import models


class DiscussChannel(models.Model):
    """Group channels (e.g. #general) are automatically joined by every internal
    user. In a shared database each customer's team must only join the
    channels of its own company, so users of other companies are excluded."""
    _inherit = 'discuss.channel'

    def _channel_home_company(self):
        self.ensure_one()
        return self.sudo().create_uid.company_id or self.env.ref('base.main_company')

    def _subscribe_users_automatically_get_members(self):
        result = super()._subscribe_users_automatically_get_members()
        Partner = self.env['res.partner'].sudo()
        for channel in self:
            company = channel._channel_home_company()
            partners = Partner.browse(result.get(channel.id, []))
            result[channel.id] = partners.filtered(
                lambda p: not p.user_ids or company in p.user_ids.company_ids).ids
        return result
