from odoo import api, fields, models

from .subscription import STATES


class ResCompany(models.Model):
    _inherit = 'res.company'

    subscription_id = fields.Many2one('bharatplus.subscription', compute='_compute_subscription')
    subscription_state = fields.Selection(STATES, string='Subscription Status', compute='_compute_subscription')

    def _compute_subscription(self):
        Subscription = self.env['bharatplus.subscription'].sudo()
        for company in self:
            subscription = Subscription.search([('company_id', '=', company.id)], limit=1)
            company.subscription_id = subscription
            company.subscription_state = subscription.state or False

    @api.model_create_multi
    def create(self, vals_list):
        companies = super().create(vals_list)
        for company in companies:
            self.env['bharatplus.subscription']._get_for_company(company)
        return companies
