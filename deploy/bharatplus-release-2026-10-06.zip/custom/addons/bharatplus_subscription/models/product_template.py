from odoo import api, models


class ProductTemplate(models.Model):
    """Products created by a customer's team are private to that company."""
    _inherit = 'product.template'

    @api.model_create_multi
    def create(self, vals_list):
        if not self.env.su and not self.env.user.has_group('base.group_system'):
            for vals in vals_list:
                if not vals.get('company_id'):
                    vals['company_id'] = self.env.company.id
        return super().create(vals_list)
