"""Stripe configuration and client factory.

Settings are read from environment variables first (deployment-managed), then
from ``ir.config_parameter`` (Settings > BharatPlus Subscription). Secrets are
never hard-coded and never committed.
"""
import json
import os

import stripe

from odoo import _
from odoo.exceptions import UserError

PARAM_PREFIX = 'bharatplus_subscription.'

ENV_VARS = {
    'stripe_secret_key': 'STRIPE_SECRET_KEY',
    'stripe_publishable_key': 'STRIPE_PUBLISHABLE_KEY',
    'stripe_webhook_secret': 'STRIPE_WEBHOOK_SECRET',
    'stripe_price_id': 'STRIPE_PRICE_ID',
}


def get_setting(env, key):
    """Return a Stripe setting: environment variable, else ir.config_parameter."""
    value = os.environ.get(ENV_VARS[key], '').strip()
    if value:
        return value
    return (env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + key) or '').strip()


def is_env_managed(key):
    return bool(os.environ.get(ENV_VARS[key], '').strip())


def stripe_mode(secret_key):
    if not secret_key:
        return 'unconfigured'
    return 'live' if secret_key.startswith('sk_live_') else 'test'


def get_client(env, secret_key=None):
    """Return a per-call StripeClient (no process-wide global key, so several
    databases with different Stripe accounts can share one Odoo process)."""
    secret_key = secret_key or get_setting(env, 'stripe_secret_key')
    if not secret_key:
        raise UserError(_(
            "Stripe is not configured. Set the Stripe secret key in "
            "Settings > BharatPlus Subscription (or the STRIPE_SECRET_KEY environment variable)."))
    return stripe.StripeClient(secret_key, max_network_retries=2)


def as_dict(obj):
    """Plain nested dict from a StripeObject/Event (SDK objects are not dicts)."""
    if isinstance(obj, stripe.StripeObject):
        recursive = getattr(obj, 'to_dict_recursive', None) or getattr(obj, '_to_dict_recursive', None)
        if recursive:
            return recursive()
        return json.loads(str(obj))
    return obj


def stripe_error_message(error):
    """Human readable message from a StripeError."""
    return getattr(error, 'user_message', None) or str(error) or error.__class__.__name__
