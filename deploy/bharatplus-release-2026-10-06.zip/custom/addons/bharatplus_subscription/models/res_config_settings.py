import stripe

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .stripe_client import as_dict, ENV_VARS, PARAM_PREFIX, get_client, get_setting, is_env_managed, stripe_error_message, stripe_mode
from .subscription import DEFAULT_UNIT_AMOUNT, STRIPE_CURRENCY

STRIPE_PRODUCT_NAME = 'BharatPlus CRM Team Member'


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    bharatplus_stripe_secret_key = fields.Char(
        string='Stripe Secret Key', config_parameter=PARAM_PREFIX + 'stripe_secret_key')
    bharatplus_stripe_publishable_key = fields.Char(
        string='Stripe Publishable Key', config_parameter=PARAM_PREFIX + 'stripe_publishable_key')
    bharatplus_stripe_webhook_secret = fields.Char(
        string='Stripe Webhook Signing Secret', config_parameter=PARAM_PREFIX + 'stripe_webhook_secret')
    bharatplus_stripe_price_id = fields.Char(
        string='Stripe Price ID', config_parameter=PARAM_PREFIX + 'stripe_price_id',
        help='Recurring price of ₹400 INR per team member per month. Use "Create Product & Price in Stripe" to create it.')
    bharatplus_stripe_mode = fields.Char(compute='_compute_stripe_info')
    bharatplus_stripe_env_managed = fields.Boolean(compute='_compute_stripe_info')
    bharatplus_webhook_url = fields.Char(compute='_compute_stripe_info')

    @api.depends('bharatplus_stripe_secret_key')
    def _compute_stripe_info(self):
        base_url = (self.env['ir.config_parameter'].sudo().get_param('web.base.url') or '').rstrip('/')
        for settings in self:
            secret = get_setting(self.env, 'stripe_secret_key') if is_env_managed('stripe_secret_key') else settings.bharatplus_stripe_secret_key
            settings.bharatplus_stripe_mode = {'live': 'LIVE', 'test': 'TEST', 'unconfigured': 'Not configured'}[stripe_mode(secret)]
            settings.bharatplus_stripe_env_managed = any(is_env_managed(key) for key in ENV_VARS)
            settings.bharatplus_webhook_url = f"{base_url}/bharatplus/stripe/webhook"

    def action_bharatplus_create_stripe_price(self):
        """Create the product + recurring price in the connected Stripe account."""
        self.ensure_one()
        secret = get_setting(self.env, 'stripe_secret_key') if is_env_managed('stripe_secret_key') else self.bharatplus_stripe_secret_key
        if not secret:
            raise UserError(_("Enter the Stripe secret key first."))
        client = get_client(self.env, secret_key=secret)
        try:
            price = self._bharatplus_find_or_create_price(client)
        except stripe.StripeError as e:
            raise UserError(_("Stripe error: %s", stripe_error_message(e)))
        # Persist immediately so the value survives even if the form is not saved
        self.env['ir.config_parameter'].sudo().set_param(PARAM_PREFIX + 'stripe_secret_key', secret)
        self.env['ir.config_parameter'].sudo().set_param(PARAM_PREFIX + 'stripe_price_id', price['id'])
        self.bharatplus_stripe_price_id = price['id']
        return {
            'type': 'ir.actions.client', 'tag': 'display_notification',
            'params': {'type': 'success', 'sticky': False, 'next': {'type': 'ir.actions.act_window_close'},
                       'message': _("Stripe product '%s' and price %s created.", STRIPE_PRODUCT_NAME, price['id'])},
        }

    @api.model
    def _bharatplus_find_or_create_price(self, client):
        """Reuse an existing active ₹400/month INR price of our product if the
        button is clicked twice; otherwise create product + price."""
        unit_amount = int(round(DEFAULT_UNIT_AMOUNT * 100))   # INR in paise: ₹400 -> 40000
        existing = as_dict(client.v1.prices.list(params={
            'active': True, 'currency': STRIPE_CURRENCY, 'type': 'recurring', 'limit': 100,
            'expand': ['data.product'],
        }))
        for price in existing.get('data', []):
            product = price.get('product') or {}
            if (price.get('unit_amount') == unit_amount
                    and (price.get('recurring') or {}).get('interval') == 'month'
                    and isinstance(product, dict) and product.get('name') == STRIPE_PRODUCT_NAME
                    and product.get('active', True)):
                return price
        product = as_dict(client.v1.products.create(params={
            'name': STRIPE_PRODUCT_NAME,
            'metadata': {'bharatplus': 'team_member'},
        }))
        return as_dict(client.v1.prices.create(params={
            'product': product['id'],
            'currency': STRIPE_CURRENCY,
            'unit_amount': unit_amount,
            'recurring': {'interval': 'month'},
            'nickname': f"₹{int(DEFAULT_UNIT_AMOUNT)} per team member per month",
        }))

    def action_bharatplus_open_subscription(self):
        return self.env['bharatplus.subscription'].action_open_my_subscription()
