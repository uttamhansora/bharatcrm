import logging

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError

from ..models.res_users import COMPANY_ADMIN_GROUP, TEAM_ROLES

_logger = logging.getLogger(__name__)

INVOICING_GROUP = 'account.group_account_invoice'
# Every group a company administrator may hand out (used to reset a member's role)
MANAGED_GROUPS = [INVOICING_GROUP] + [xmlid for _label, xmlids in TEAM_ROLES.values() for xmlid in xmlids]


class BharatplusTeamInvite(models.TransientModel):
    """Invite a new team member, or change the role of an existing one."""
    _name = 'bharatplus.team.invite'
    _description = 'Invite / Change Role of a Team Member'

    user_id = fields.Many2one('res.users', string='Team Member', readonly=True)
    name = fields.Char(string='Full Name', required=True)
    email = fields.Char(string='Email', required=True)
    role = fields.Selection(
        [(key, label) for key, (label, _groups) in TEAM_ROLES.items()],
        string='Role', required=True, default='sales_own')
    invoicing = fields.Boolean(
        string='Access to Invoicing', default=True,
        help='Can create customer invoices and register payments. Company administrators always have it.')
    company_id = fields.Many2one(
        'res.company', string='Company', required=True, readonly=True,
        default=lambda self: self.env.company)
    unit_amount = fields.Integer(compute='_compute_billing_preview')
    member_count = fields.Integer(string='Active Members Today', compute='_compute_billing_preview')
    monthly_amount_now = fields.Integer(compute='_compute_billing_preview')
    monthly_amount_after = fields.Integer(compute='_compute_billing_preview')
    billing_note = fields.Char(compute='_compute_billing_preview')

    @api.depends('company_id', 'user_id')
    def _compute_billing_preview(self):
        """Show what the new member does to the bill: +₹400 per active member per month."""
        from ..models.subscription import DEFAULT_UNIT_AMOUNT
        unit = int(DEFAULT_UNIT_AMOUNT)
        for wizard in self:
            sub = self.env['bharatplus.subscription'].sudo()._get_for_company(wizard.company_id, create=False) \
                if wizard.company_id else None
            count = len(sub._get_billable_users()) if sub else 0
            wizard.unit_amount = unit
            wizard.member_count = count
            wizard.monthly_amount_now = max(count, 1) * unit
            wizard.monthly_amount_after = (count + (0 if wizard.user_id else 1)) * unit
            if sub and sub.state == 'trialing' and sub.trial_end:
                wizard.billing_note = _("Free until your trial ends on %s, then ₹%s per month.",
                                        fields.Date.to_string(sub.trial_end.date()), f"{wizard.monthly_amount_after:,}")
            elif sub and sub.stripe_subscription_id:
                wizard.billing_note = _("Your monthly amount becomes ₹%s (prorated on the next invoice).",
                                        f"{wizard.monthly_amount_after:,}")
            else:
                wizard.billing_note = _("Members are billed at ₹%s per month each once your subscription is started.", unit)

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        user_id = values.get('user_id') or self.env.context.get('default_user_id')
        if user_id:
            user = self.env['res.users'].browse(user_id)
            values.update({
                'user_id': user.id, 'name': user.name, 'email': user.login, 'company_id': user.company_id.id,
                'role': 'admin' if user.has_group(COMPANY_ADMIN_GROUP)
                        else 'sales_all' if user.has_group('sales_team.group_sale_salesman_all_leads')
                        else 'sales_own',
                'invoicing': user.has_group(INVOICING_GROUP),
            })
        return values

    def _role_groups(self):
        xmlids = list(TEAM_ROLES[self.role][1])
        if self.invoicing or self.role == 'admin':
            xmlids.append(INVOICING_GROUP)
        return [self.env.ref(xmlid).id for xmlid in xmlids]

    def _check_rights(self):
        current = self.env.user
        if not current._is_bharatplus_manager() or self.company_id not in current.company_ids:
            raise AccessError(_("Only a company administrator can manage team members."))

    def action_invite(self):
        """Create the team member (internal user of the company) and send the
        set-password invitation. The Stripe quantity follows automatically."""
        self.ensure_one()
        self._check_rights()
        if self.user_id:
            return self.action_change_role()
        email = (self.email or '').strip().lower()
        if '@' not in email or '.' not in email.split('@')[-1]:
            raise UserError(_("Please enter a valid email address."))
        Users = self.env['res.users'].sudo().with_context(active_test=False)
        if Users.search_count([('login', '=ilike', email)]):
            raise UserError(_("A user with the email %s already exists.", email))

        user = Users.with_context(no_reset_password=True).create({
            'name': (self.name or '').strip(),
            'login': email,
            'email': email,
            'company_id': self.company_id.id,
            'company_ids': [(6, 0, [self.company_id.id])],
            'group_ids': [(6, 0, self._role_groups())],
        })
        user.partner_id.write({'company_id': self.company_id.id})
        try:
            user.with_context(create_user=True).action_reset_password()   # invitation e-mail
        except Exception:  # noqa: BLE001 - a missing mail server must not block the invite
            _logger.warning("Could not send the invitation e-mail to %s", email, exc_info=True)
        return self._notify(_("%s has been added to your team.", user.name))

    def action_change_role(self):
        """Replace the managed groups of an existing member with the chosen role."""
        self.ensure_one()
        self._check_rights()
        user = self.user_id
        user._bharatplus_check_team_admin()
        if user == self.env.user and self.role != 'admin':
            raise UserError(_("You cannot remove your own administrator role."))
        managed = [self.env.ref(xmlid).id for xmlid in MANAGED_GROUPS]
        commands = [(3, gid) for gid in managed] + [(4, gid) for gid in self._role_groups()]
        user.sudo().write({'group_ids': commands})
        return self._notify(_("%s is now %s.", user.name, dict(self._fields['role'].selection)[self.role]))

    def _notify(self, message):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {'type': 'success', 'message': message,
                       'next': {'type': 'ir.actions.act_window_close'}},
        }
