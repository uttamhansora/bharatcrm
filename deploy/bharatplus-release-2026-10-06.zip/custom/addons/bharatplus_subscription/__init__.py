from . import models
from . import controllers
from . import wizard


def post_init_hook(env):
    """Give every existing company a (not yet started) subscription record."""
    Subscription = env['bharatplus.subscription']
    for company in env['res.company'].sudo().search([]):
        Subscription._get_for_company(company)
