import logging

import stripe
from werkzeug.exceptions import Forbidden

from odoo import http
from odoo.http import request

from ..models.stripe_client import get_client

_logger = logging.getLogger(__name__)

BILLING_PAGE = '/crm/action-bharatplus_subscription.action_open_subscription'


class BillingController(http.Controller):

    @http.route('/bharatplus/billing/return', type='http', auth='user', methods=['GET'])
    def billing_return(self, session_id=None, **kwargs):
        """Return URL of Stripe Checkout (payment method setup). The session is
        re-read from Stripe with our secret key; nothing from the query string
        is trusted beyond the session id."""
        if not request.env.user._is_bharatplus_manager():
            raise Forbidden()
        subscription = request.env['bharatplus.subscription']._get_for_company(request.env.company)
        if session_id:
            try:
                client = get_client(request.env)
                session = client.v1.checkout.sessions.retrieve(session_id, params={'expand': ['setup_intent']})
                subscription._handle_checkout_session(session, client)   # checks the customer matches
            except stripe.StripeError as e:
                _logger.warning("Could not read Checkout session %s: %s", session_id, e)
        return request.redirect(BILLING_PAGE)
