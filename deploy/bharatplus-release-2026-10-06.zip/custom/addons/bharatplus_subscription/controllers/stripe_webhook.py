import logging

import stripe

from odoo import http
from odoo.http import request

from ..models.stripe_client import as_dict, get_setting

_logger = logging.getLogger(__name__)


class StripeWebhookController(http.Controller):

    @http.route('/bharatplus/stripe/webhook', type='http', auth='public', methods=['POST'], csrf=False, save_session=False)
    def stripe_webhook(self, **kwargs):
        """Receive Stripe events. The payload is only trusted after its
        signature has been verified with the endpoint's signing secret."""
        secret = get_setting(request.env, 'stripe_webhook_secret')
        if not secret:
            _logger.error("Stripe webhook received but no signing secret is configured")
            return request.make_response('Webhook secret not configured', status=500)

        payload = request.httprequest.get_data()
        signature = request.httprequest.headers.get('Stripe-Signature', '')
        try:
            event = stripe.Webhook.construct_event(payload, signature, secret)
        except (ValueError, stripe.SignatureVerificationError) as e:
            _logger.warning("Rejected Stripe webhook: %s", e)
            return request.make_response('Invalid signature', status=400)
        event = as_dict(event)

        Event = request.env['bharatplus.stripe.event'].sudo()
        record, is_new = Event._register_event(event)
        if not is_new and record.processed:
            return request.make_response('Already processed', status=200)

        try:
            with request.env.cr.savepoint():
                record._process(event)
                record.write({'processed': True, 'error': False})
        except Exception as e:  # noqa: BLE001 - report to Stripe so the event is retried
            _logger.exception("Error while processing Stripe event %s", event['id'])
            record.write({'error': str(e)})
            return request.make_response('Processing error', status=500)
        return request.make_response('OK', status=200)
