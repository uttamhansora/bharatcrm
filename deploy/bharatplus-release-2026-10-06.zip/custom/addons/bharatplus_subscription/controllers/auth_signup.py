import logging

from odoo import _
from odoo.exceptions import UserError
from odoo.http import request
from odoo.addons.auth_signup.controllers.main import AuthSignupHome

_logger = logging.getLogger(__name__)


class BharatplusAuthSignupHome(AuthSignupHome):
    """Business signup: the public signup form asks for the company name; an
    uninvited signup then creates a new company with its administrator
    (see res.users._signup_create_user)."""

    def get_auth_signup_qcontext(self):
        qcontext = super().get_auth_signup_qcontext()
        qcontext['company_name'] = request.params.get('company_name', '')
        return qcontext

    def _prepare_signup_values(self, qcontext):
        values = super()._prepare_signup_values(qcontext)
        if not qcontext.get('token'):
            company_name = (qcontext.get('company_name') or '').strip()
            if not company_name:
                raise UserError(_("Please enter your company name."))
            values['company_name'] = company_name
        return values

    def _signup_with_values(self, token, values, do_login):
        """The standard flow authenticates the session *before* the signup
        transaction is committed. If the transaction then fails (e.g. a
        serialization retry), the session must not stay logged in as a user
        that was rolled back."""
        try:
            return super()._signup_with_values(token, values, do_login)
        except Exception:
            if request.session.uid or request.session.get('pre_uid'):
                _logger.info("Signup failed after authentication: clearing the session")
                request.session.logout(keep_db=True)
            raise
