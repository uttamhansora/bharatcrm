import time
from unittest.mock import MagicMock, patch

import stripe

from odoo.tests import TransactionCase

PARAM = 'bharatplus_subscription.'
WEBHOOK_SECRET = 'whsec_test_secret'


def stripe_obj(data):
    """Build a StripeObject (dict + attribute access) like the SDK returns."""
    return stripe.StripeObject.construct_from(data, 'sk_test_x')


def make_subscription(quantity, status='trialing', sub_id='sub_test_1', customer='cus_test_1',
                      trial_end=None, cancel_at_period_end=False, payment_method=None, now=None):
    now = now or int(time.time())
    trial_start = now if trial_end else None
    return stripe_obj({
        'id': sub_id, 'object': 'subscription', 'status': status, 'customer': customer, 'livemode': False,
        'trial_start': trial_start, 'trial_end': trial_end,
        'cancel_at_period_end': cancel_at_period_end, 'cancel_at': None, 'canceled_at': None,
        'default_payment_method': payment_method,
        'items': {'object': 'list', 'data': [{
            'id': 'si_test_1', 'object': 'subscription_item', 'quantity': quantity,
            'current_period_start': now, 'current_period_end': now + 30 * 86400,
            'price': {'id': 'price_test_1', 'object': 'price', 'unit_amount': 40000, 'currency': 'inr'},
        }]},
    })


class FakeStripe:
    """In-memory stand-in for StripeClient.v1 that records calls."""

    def __init__(self):
        self.quantity = None
        self.status = 'trialing'
        self.cancel_at_period_end = False
        self.trial_end = None
        self.payment_method = None
        self.fail_update = None

        self.customers = MagicMock()
        self.customers.create.side_effect = lambda params: stripe_obj({'id': 'cus_test_1', 'object': 'customer', **params})
        self.customers.update.side_effect = lambda cid, params: stripe_obj({'id': cid, 'object': 'customer'})
        self.customers.retrieve.side_effect = lambda cid: stripe_obj({
            'id': cid, 'object': 'customer',
            'invoice_settings': {'default_payment_method': self.payment_method}})

        self.subscriptions = MagicMock()
        self.subscriptions.create.side_effect = self._create
        self.subscriptions.update.side_effect = self._update
        self.subscriptions.retrieve.side_effect = lambda sid: self._current()
        self.subscriptions.resume.side_effect = lambda sid, params: self._resume()

        self.checkout = MagicMock()
        self.checkout.sessions.create.side_effect = lambda params: stripe_obj({
            'id': 'cs_test_1', 'object': 'checkout.session', 'url': 'https://checkout.stripe.com/c/pay/cs_test_1', **params})
        self.billing_portal = MagicMock()
        self.billing_portal.sessions.create.side_effect = lambda params: stripe_obj({
            'id': 'bps_test_1', 'url': 'https://billing.stripe.com/p/session/test_1'})
        self.setup_intents = MagicMock()
        self.payment_methods = MagicMock()
        self.payment_methods.retrieve.side_effect = lambda pm: stripe_obj({
            'id': pm, 'object': 'payment_method', 'type': 'card', 'card': {'brand': 'visa', 'last4': '4242'}})
        self.products = MagicMock()
        self.products.create.side_effect = lambda params: stripe_obj({'id': 'prod_test_1', **params})
        self.prices = MagicMock()
        self.prices.create.side_effect = lambda params: stripe_obj({'id': 'price_test_1', **params})

    # -- subscription behaviour
    def _current(self):
        return make_subscription(self.quantity, status=self.status, trial_end=self.trial_end,
                                 cancel_at_period_end=self.cancel_at_period_end,
                                 payment_method=self.payment_method)

    def _create(self, params):
        self.quantity = params['items'][0]['quantity']
        self.trial_end = params.get('trial_end')
        self.status = 'trialing' if self.trial_end else 'active'
        return self._current()

    def _update(self, sub_id, params):
        if self.fail_update:
            raise self.fail_update
        if 'items' in params:
            self.quantity = params['items'][0]['quantity']
        if 'cancel_at_period_end' in params:
            self.cancel_at_period_end = params['cancel_at_period_end']
        if 'default_payment_method' in params:
            self.payment_method = params['default_payment_method']
        return self._current()

    def _resume(self):
        self.status = 'active'
        return self._current()


class SubscriptionCase(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        ICP = cls.env['ir.config_parameter'].sudo()
        ICP.set_param(PARAM + 'stripe_secret_key', 'sk_test_dummy')
        ICP.set_param(PARAM + 'stripe_price_id', 'price_test_1')
        ICP.set_param(PARAM + 'stripe_webhook_secret', WEBHOOK_SECRET)
        cls.company = cls.env['res.company'].create({'name': 'Acme Traders'})
        cls.other_company = cls.env['res.company'].create({'name': 'Zeta Ltd'})
        cls.group_system = cls.env.ref('base.group_system')
        cls.group_user = cls.env.ref('base.group_user')
        cls.admin = cls._make_user('acme_admin', cls.company, system=True)
        cls.member = cls._make_user('acme_member', cls.company)
        cls.other_admin = cls._make_user('zeta_admin', cls.other_company, system=True)
        cls.subscription = cls.env['bharatplus.subscription']._get_for_company(cls.company)
        cls.other_subscription = cls.env['bharatplus.subscription']._get_for_company(cls.other_company)

    @classmethod
    def _make_user(cls, login, company, system=False, portal=False):
        if portal:
            groups = [cls.env.ref('base.group_portal').id]
        else:
            groups = [cls.group_user.id] + ([cls.group_system.id] if system else [])
        return cls.env['res.users'].with_context(no_reset_password=True).create({
            'name': login, 'login': login, 'email': f'{login}@example.com',
            'company_id': company.id, 'company_ids': [(6, 0, [company.id])],
            'group_ids': [(6, 0, groups)],
        })

    def setUp(self):
        super().setUp()
        self.fake = FakeStripe()
        client = MagicMock()
        client.v1 = self.fake
        patcher = patch('odoo.addons.bharatplus_subscription.models.stripe_client.stripe.StripeClient', return_value=client)
        patcher.start()
        self.addCleanup(patcher.stop)

    def sub_as_admin(self):
        return self.subscription.with_user(self.admin).with_company(self.company)
