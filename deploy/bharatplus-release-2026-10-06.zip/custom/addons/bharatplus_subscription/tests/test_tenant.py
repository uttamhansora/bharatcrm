import re
from unittest.mock import MagicMock, patch

from odoo.exceptions import AccessError, UserError
from odoo.tests import HttpCase, tagged

from .common import FakeStripe, PARAM, SubscriptionCase

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')
ADMIN_GROUP = 'bharatplus_subscription.group_company_admin'


@tagged('post_install', '-at_install', 'bharatplus_subscription')
class TestTenant(SubscriptionCase):

    def _signup_business(self, login='owner@newbiz.example', company='New Biz Pvt Ltd'):
        self.env['res.users'].sudo().signup({
            'name': 'Owner', 'login': login, 'password': 'Str0ngPassw0rd!', 'company_name': company})
        return self.env['res.users'].sudo().search([('login', '=', login)])

    def test_01_business_signup_creates_company_and_admin(self):
        owner = self._signup_business()
        self.assertTrue(owner)
        self.assertEqual(owner.company_id.name, 'New Biz Pvt Ltd')
        self.assertEqual(owner.company_ids, owner.company_id)
        self.assertFalse(owner.share, "business signup gives an internal user")
        self.assertTrue(owner.has_group(ADMIN_GROUP))
        self.assertTrue(owner.has_group('sales_team.group_sale_manager'))
        self.assertFalse(owner.has_group('base.group_system'), "never a system administrator")
        self.assertTrue(owner._is_bharatplus_manager())
        self.assertEqual(owner.company_id.currency_id.name, 'INR')
        self.assertEqual(owner.company_id.country_id.code, 'IN')
        self.assertEqual(owner.partner_id.company_id, owner.company_id)
        self.assertEqual(owner.company_id.subscription_id.state, 'draft')
        self.assertEqual(owner.company_id.subscription_id.member_count, 1)
        # same email twice is refused
        with self.assertRaises(UserError):
            self._signup_business(company='Another')

    def test_02_plain_signup_without_company_stays_portal(self):
        self.env['res.users'].sudo().signup({'name': 'Visitor', 'login': 'visitor@example.com', 'password': 'Str0ngPassw0rd!'})
        visitor = self.env['res.users'].sudo().search([('login', '=', 'visitor@example.com')])
        self.assertTrue(visitor.share)

    def test_03_company_admin_starts_trial_and_invites(self):
        owner = self._signup_business()
        sub = owner.company_id.subscription_id.with_user(owner).with_company(owner.company_id)
        sub.action_start_subscription()
        self.assertEqual(self.fake.quantity, 1)
        # invite a salesperson -> user in the same company, quantity 2
        wizard = self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id).create({
            'name': 'Priya', 'email': 'priya@newbiz.example', 'role': 'sales_own'})
        wizard.action_invite()
        priya = self.env['res.users'].sudo().search([('login', '=', 'priya@newbiz.example')])
        self.assertEqual(priya.company_id, owner.company_id)
        self.assertTrue(priya.has_group('sales_team.group_sale_salesman'))
        self.assertTrue(priya.has_group('account.group_account_invoice'), "invoicing access by default")
        self.assertFalse(priya.has_group(ADMIN_GROUP))
        self.assertFalse(priya.has_group('base.group_system'))
        # change role: salesperson (all documents) without invoicing
        change = self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id) \
            .with_context(default_user_id=priya.id).create({'role': 'sales_all', 'invoicing': False})
        self.assertEqual(change.email, 'priya@newbiz.example')
        change.action_change_role()
        priya.invalidate_recordset()
        self.assertTrue(priya.has_group('sales_team.group_sale_salesman_all_leads'))
        self.assertFalse(priya.has_group('account.group_account_invoice'))
        # promote to company administrator, then the owner cannot demote themselves
        self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id) \
            .with_context(default_user_id=priya.id).create({'role': 'admin'}).action_change_role()
        self.assertTrue(priya.has_group(ADMIN_GROUP))
        with self.assertRaises(UserError):
            self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id) \
                .with_context(default_user_id=owner.id).create({'role': 'sales_own'}).action_change_role()
        self.assertEqual(priya.partner_id.company_id, owner.company_id)
        self.assertEqual(self.fake.quantity, 2)
        # deactivate -> quantity 1; cannot deactivate self; reactivate -> 2
        priya.with_user(owner).with_company(owner.company_id).action_bharatplus_deactivate()
        self.assertFalse(priya.active)
        self.assertEqual(self.fake.quantity, 1)
        with self.assertRaises(UserError):
            owner.with_user(owner).action_bharatplus_deactivate()
        priya.with_user(owner).with_company(owner.company_id).action_bharatplus_reactivate()
        self.assertEqual(self.fake.quantity, 2)

    def test_04_tenant_isolation(self):
        owner = self._signup_business()
        other = self._signup_business(login='owner@other.example', company='Other Co')
        Users = self.env['res.users'].with_user(owner).with_company(owner.company_id)
        visible = Users.search([('share', '=', False)])
        self.assertIn(owner, visible)
        self.assertNotIn(other, visible, "users of other companies are invisible")
        self.assertNotIn(self.admin, visible)
        # cannot manage a user of another company
        with self.assertRaises(AccessError):
            other.with_user(owner).with_company(owner.company_id).action_bharatplus_deactivate()
        # cannot read the other company's subscription
        with self.assertRaises(AccessError):
            other.company_id.subscription_id.with_user(owner).read(['state'])
        # cannot invite into another company
        with self.assertRaises(AccessError):
            self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id).create({
                'name': 'X', 'email': 'x@x.example', 'role': 'sales_own', 'company_id': other.company_id.id,
            }).action_invite()
        # contacts created by a tenant belong to the tenant's company
        partner = self.env['res.partner'].with_user(owner).with_company(owner.company_id).create({'name': 'Lead Customer'})
        self.assertEqual(partner.company_id, owner.company_id)
        self.assertFalse(self.env['res.partner'].with_user(other).with_company(other.company_id).search([('id', '=', partner.id)]))
        # no privilege escalation: no write access on users, and the guard refuses admin groups anyway
        with self.assertRaises(AccessError):
            owner.with_user(owner).write({'group_ids': [(4, self.env.ref('base.group_system').id)]})
        # system administrators still see everyone
        self.assertIn(other, self.env['res.users'].with_user(self.env.ref('base.user_admin')).search([]))

    def test_05_tenant_users_do_not_join_main_company_channels(self):
        general = self.env.ref('mail.channel_all_employees', raise_if_not_found=False)
        if not general:
            self.skipTest('no #general channel')
        owner = self._signup_business()
        self.assertNotIn(owner.partner_id, general.channel_partner_ids, "tenant admin is not in #general")
        wizard = self.env['bharatplus.team.invite'].with_user(owner).with_company(owner.company_id).create({
            'name': 'Priya', 'email': 'priya@newbiz.example', 'role': 'sales_own'})
        wizard.action_invite()
        priya = self.env['res.users'].sudo().search([('login', '=', 'priya@newbiz.example')])
        self.assertNotIn(priya.partner_id, general.channel_partner_ids, "tenant member is not in #general")
        # an internal user of the main company still joins
        colleague = self._make_user('main_colleague', self.env.ref('base.main_company'))
        self.assertIn(colleague.partner_id, general.channel_partner_ids)


@tagged('post_install', '-at_install', 'bharatplus_subscription')
class TestBusinessSignupHttp(HttpCase):

    def setUp(self):
        super().setUp()
        ICP = self.env['ir.config_parameter'].sudo()
        ICP.set_param(PARAM + 'stripe_secret_key', 'sk_test_dummy')
        ICP.set_param(PARAM + 'stripe_price_id', 'price_test_1')
        self.fake = FakeStripe()
        client = MagicMock()
        client.v1 = self.fake
        patcher = patch('odoo.addons.bharatplus_subscription.models.stripe_client.stripe.StripeClient', return_value=client)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_signup_from_pricing_lands_on_trial_confirmation(self):
        page = self.url_open('/web/signup?redirect=%2Fpricing%2Fstart')
        self.assertEqual(page.status_code, 200)
        self.assertIn('name="company_name"', page.text)
        csrf_token = CSRF_RE.search(page.text).group(1)
        response = self.url_open('/web/signup', data={
            'csrf_token': csrf_token, 'company_name': 'Web Biz', 'name': 'Web Owner',
            'login': 'web.owner@example.com', 'password': 'Str0ngPassw0rd!', 'confirm_password': 'Str0ngPassw0rd!',
            'redirect': '/pricing/start', 'token': '',
        })
        self.assertEqual(response.status_code, 200)
        self.assertIn('Start my free trial', response.text, "logged in and on the trial confirmation page")
        owner = self.env['res.users'].sudo().search([('login', '=', 'web.owner@example.com')])
        self.assertEqual(owner.company_id.name, 'Web Biz')
        self.assertTrue(owner.has_group(ADMIN_GROUP))
        # start the trial through the page
        csrf_token = CSRF_RE.search(response.text).group(1)
        response = self.url_open('/pricing/start', data={'csrf_token': csrf_token}, allow_redirects=False)
        self.assertIn(response.status_code, (302, 303))
        self.assertIn('/pricing/started', response.headers['Location'])
        self.assertEqual(self.fake.subscriptions.create.call_args.kwargs['params']['items'][0]['quantity'], 1)
        # /crm is reachable (internal user)
        response = self.url_open('/crm', allow_redirects=False)
        self.assertEqual(response.status_code, 200)
