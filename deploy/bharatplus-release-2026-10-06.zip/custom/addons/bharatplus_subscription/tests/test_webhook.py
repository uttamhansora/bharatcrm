import json
import time
from unittest.mock import MagicMock, patch

import stripe

from odoo.tests import HttpCase, tagged

from ..models.stripe_client import as_dict
from .common import FakeStripe, PARAM, WEBHOOK_SECRET, make_subscription

WEBHOOK = '/bharatplus/stripe/webhook'


def sign(payload, secret=WEBHOOK_SECRET, timestamp=None):
    timestamp = timestamp or int(time.time())
    signature = stripe.WebhookSignature._compute_signature(f"{timestamp}.{payload}", secret)
    return f"t={timestamp},v1={signature}"


@tagged('post_install', '-at_install', 'bharatplus_subscription')
class TestStripeWebhook(HttpCase):

    def setUp(self):
        super().setUp()
        ICP = self.env['ir.config_parameter'].sudo()
        ICP.set_param(PARAM + 'stripe_secret_key', 'sk_test_dummy')
        ICP.set_param(PARAM + 'stripe_price_id', 'price_test_1')
        ICP.set_param(PARAM + 'stripe_webhook_secret', WEBHOOK_SECRET)
        self.company = self.env['res.company'].create({'name': 'Acme Traders'})
        self.subscription = self.env['bharatplus.subscription']._get_for_company(self.company)
        self.fake = FakeStripe()
        self.fake.quantity = 1
        client = MagicMock()
        client.v1 = self.fake
        patcher = patch('odoo.addons.bharatplus_subscription.models.stripe_client.stripe.StripeClient', return_value=client)
        patcher.start()
        self.addCleanup(patcher.stop)
        # subscription already linked to Stripe
        self.subscription._apply_stripe_subscription(make_subscription(1, trial_end=int(time.time()) + 20 * 86400))
        self.subscription.write({'stripe_customer_id': 'cus_test_1'})

    def _post(self, event, signature=None):
        payload = json.dumps(event)
        return self.url_open(WEBHOOK, data=payload, headers={
            'Content-Type': 'application/json',
            'Stripe-Signature': signature if signature is not None else sign(payload),
        })

    def _event(self, event_id, event_type, obj):
        return {'id': event_id, 'object': 'event', 'type': event_type, 'livemode': False,
                'created': int(time.time()), 'data': {'object': obj}}

    def _invoice(self, paid):
        return {'id': 'in_test_1', 'object': 'invoice', 'customer': 'cus_test_1', 'currency': 'inr',
                'amount_due': 40000, 'amount_paid': 40000 if paid else 0, 'created': int(time.time()),
                'hosted_invoice_url': 'https://invoice.stripe.com/i/in_test_1',
                'parent': {'subscription_details': {'subscription': 'sub_test_1'}}}

    def test_01_invalid_signature_is_rejected(self):
        event = self._event('evt_bad', 'invoice.paid', self._invoice(True))
        self.assertEqual(self._post(event, signature='t=1,v1=deadbeef').status_code, 400)
        self.assertEqual(self._post(event, signature=sign(json.dumps(event), secret='whsec_wrong')).status_code, 400)
        self.assertFalse(self.env['bharatplus.stripe.event'].search([('event_id', '=', 'evt_bad')]))
        self.assertFalse(self.subscription.last_payment_status)

    def test_02_payment_failed_then_paid(self):
        response = self._post(self._event('evt_fail', 'invoice.payment_failed', self._invoice(False)))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.subscription.last_payment_status, 'failed')
        self.assertEqual(self.subscription.last_invoice_url, 'https://invoice.stripe.com/i/in_test_1')
        response = self._post(self._event('evt_paid', 'invoice.paid', self._invoice(True)))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.subscription.last_payment_status, 'paid')

    def test_03_duplicate_event_is_processed_once(self):
        event = self._event('evt_dup', 'invoice.paid', self._invoice(True))
        messages_before = len(self.subscription.message_ids)
        self.assertEqual(self._post(event).status_code, 200)
        messages_after_first = len(self.subscription.message_ids)
        self.assertGreater(messages_after_first, messages_before, "first delivery posted the payment message")
        self.assertEqual(self._post(event).status_code, 200)
        self.assertEqual(self._post(event).status_code, 200)
        records = self.env['bharatplus.stripe.event'].search([('event_id', '=', 'evt_dup')])
        self.assertEqual(len(records), 1)
        self.assertTrue(records.processed)
        self.assertEqual(len(self.subscription.message_ids), messages_after_first, "redeliveries ran no business action")

    def test_04_subscription_updated_syncs_state_and_reconciles_quantity(self):
        # Stripe says: active, quantity 4 (wrong: the company has no internal users yet -> billable 1)
        self.fake.status = 'active'
        self.fake.cancel_at_period_end = True
        obj = make_subscription(4, status='active', cancel_at_period_end=True)
        response = self._post(self._event('evt_upd', 'customer.subscription.updated', as_dict(obj)))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.subscription.state, 'active')
        self.assertTrue(self.subscription.cancel_at_period_end)
        self.assertEqual(self.fake.quantity, 1, "quantity reconciled to the real member count")

    def test_05_subscription_deleted_and_trial_will_end(self):
        obj = make_subscription(1, status='canceled')
        self.assertEqual(self._post(self._event('evt_del', 'customer.subscription.deleted', as_dict(obj))).status_code, 200)
        self.assertEqual(self.subscription.state, 'canceled')
        obj = make_subscription(1, status='trialing', trial_end=int(time.time()) + 3 * 86400)
        self.assertEqual(self._post(self._event('evt_twe', 'customer.subscription.trial_will_end', as_dict(obj))).status_code, 200)
        self.assertEqual(self.subscription.state, 'trialing')

    def test_06_unknown_subscription_is_ignored(self):
        obj = as_dict(make_subscription(9, status='active', sub_id='sub_unknown', customer='cus_unknown'))
        self.assertEqual(self._post(self._event('evt_unknown', 'customer.subscription.updated', obj)).status_code, 200)
        self.assertEqual(self.subscription.quantity, 1)

    def test_07_checkout_session_completed_attaches_payment_method(self):
        self.fake.setup_intents.retrieve.side_effect = lambda sid: {'id': sid, 'payment_method': 'pm_test_9'}
        obj = {'id': 'cs_test_1', 'object': 'checkout.session', 'mode': 'setup', 'status': 'complete',
               'customer': 'cus_test_1', 'setup_intent': 'seti_9',
               'metadata': {'bharatplus_company_id': str(self.company.id)}}
        self.assertEqual(self._post(self._event('evt_cs', 'checkout.session.completed', obj)).status_code, 200)
        self.assertTrue(self.subscription.payment_method_set)
        self.assertEqual(self.subscription.stripe_payment_method_id, 'pm_test_9')

    def test_08_return_url_requires_admin(self):
        response = self.url_open('/bharatplus/billing/return?session_id=cs_x', allow_redirects=False)
        self.assertIn(response.status_code, (302, 303), "anonymous users are sent to login")
        self.assertIn('/web/login', response.headers.get('Location', ''))
