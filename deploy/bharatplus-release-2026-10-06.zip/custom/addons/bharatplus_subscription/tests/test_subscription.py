import time

import stripe
from dateutil.relativedelta import relativedelta

from odoo import fields
from odoo.exceptions import AccessError, UserError
from odoo.tests import tagged

from .common import SubscriptionCase


@tagged('post_install', '-at_install', 'bharatplus_subscription')
class TestSubscription(SubscriptionCase):

    def test_01_member_count_is_internal_active_users_of_company(self):
        self.assertEqual(self.subscription.member_count, 2)   # acme_admin + acme_member
        self._make_user('acme_portal', self.company, portal=True)
        self.assertEqual(self.subscription._billable_quantity(), 2, "portal users are not billed")
        self.assertEqual(self.other_subscription.member_count, 1)

    def test_02_start_subscription_creates_customer_and_trial(self):
        sub = self.sub_as_admin()
        sub.action_start_subscription()
        self.fake.customers.create.assert_called_once()
        self.assertEqual(self.fake.customers.create.call_args.kwargs['params']['name'], 'Acme Traders')
        params = self.fake.subscriptions.create.call_args.kwargs['params']
        self.assertEqual(params['items'], [{'price': 'price_test_1', 'quantity': 2}])
        self.assertEqual(params['trial_settings'], {'end_behavior': {'missing_payment_method': 'pause'}})
        expected = fields.Datetime.now() + relativedelta(months=1)
        self.assertAlmostEqual(params['trial_end'], int(time.time()) + int((expected - fields.Datetime.now()).total_seconds()), delta=120)
        self.assertEqual(sub.state, 'trialing')
        self.assertEqual(sub.quantity, 2)
        self.assertEqual(sub.stripe_customer_id, 'cus_test_1')
        self.assertEqual(sub.stripe_subscription_id, 'sub_test_1')
        self.assertTrue(sub.trial_used)
        self.assertEqual(sub.monthly_amount, 800)
        self.assertEqual(sub.unit_amount, 400)
        self.assertEqual(sub.next_billing_date, sub.trial_end)
        # a second start is refused and no duplicate customer is created
        with self.assertRaises(UserError):
            sub.action_start_subscription()
        self.fake.customers.create.assert_called_once()

    def test_03_add_member_increases_stripe_quantity(self):
        self.sub_as_admin().action_start_subscription()
        self._make_user('acme_member2', self.company)
        self.assertEqual(self.fake.quantity, 3)
        self.assertEqual(self.subscription.quantity, 3)
        self.assertEqual(self.subscription.monthly_amount, 1200)
        # portal user: no Stripe call
        calls = self.fake.subscriptions.update.call_count
        self._make_user('acme_portal', self.company, portal=True)
        self.assertEqual(self.fake.subscriptions.update.call_count, calls)

    def test_04_remove_member_decreases_stripe_quantity(self):
        self.sub_as_admin().action_start_subscription()
        member2 = self._make_user('acme_member2', self.company)
        self.assertEqual(self.fake.quantity, 3)
        member2.action_archive()
        self.assertEqual(self.fake.quantity, 2)
        self.assertEqual(self.subscription.quantity, 2)
        self.member.unlink()
        self.assertEqual(self.fake.quantity, 1)
        self.assertEqual(self.subscription.quantity, 1)

    def test_05_stripe_failure_rolls_back_member_change(self):
        self.sub_as_admin().action_start_subscription()
        self.fake.fail_update = stripe.APIConnectionError('Stripe unreachable')
        with self.assertRaises(UserError), self.cr.savepoint():
            self._make_user('acme_member2', self.company)
        self.assertFalse(self.env['res.users'].search([('login', '=', 'acme_member2')]))
        self.assertEqual(self.subscription.quantity, 2)

    def test_06_other_company_members_do_not_affect_quantity(self):
        self.sub_as_admin().action_start_subscription()
        self._make_user('zeta_member', self.other_company)
        self.assertEqual(self.fake.quantity, 2)
        self.assertEqual(self.other_subscription.state, 'draft')

    def test_07_cancel_and_resume(self):
        sub = self.sub_as_admin()
        sub.action_start_subscription()
        sub.action_cancel()
        self.assertTrue(sub.cancel_at_period_end)
        self.assertEqual(self.fake.subscriptions.update.call_args.kwargs['params'], {'cancel_at_period_end': True})
        self.assertFalse(sub.next_billing_date)
        sub.action_resume()
        self.assertFalse(sub.cancel_at_period_end)

    def test_08_restart_after_cancel_has_no_trial(self):
        sub = self.sub_as_admin()
        sub.action_start_subscription()
        sub._apply_stripe_subscription(self.fake._current())
        sub.write({'state': 'canceled'})
        sub.action_start_subscription()
        params = self.fake.subscriptions.create.call_args.kwargs['params']
        self.assertNotIn('trial_end', params)
        self.assertNotIn('trial_settings', params)
        self.fake.customers.create.assert_called_once()   # customer reused

    def test_09_add_payment_method_uses_checkout_setup(self):
        sub = self.sub_as_admin()
        sub.action_start_subscription()
        action = sub.action_add_payment_method()
        self.assertEqual(action['type'], 'ir.actions.act_url')
        params = self.fake.checkout.sessions.create.call_args.kwargs['params']
        self.assertEqual(params['mode'], 'setup')
        self.assertEqual(params['customer'], 'cus_test_1')
        self.assertIn('/bharatplus/billing/return?session_id=', params['success_url'])
        # completing the session attaches the card to customer + subscription
        session = {'mode': 'setup', 'status': 'complete', 'customer': 'cus_test_1',
                   'setup_intent': {'id': 'seti_1', 'payment_method': 'pm_test_1'}}
        self.assertTrue(sub._handle_checkout_session(session))
        self.fake.customers.update.assert_called_once_with('cus_test_1', params={'invoice_settings': {'default_payment_method': 'pm_test_1'}})
        self.assertTrue(sub.payment_method_set)
        self.assertEqual(sub.payment_method_label, 'Visa •••• 4242')
        self.assertFalse(sub._handle_checkout_session(session), "idempotent")
        # a session of another customer is ignored
        self.assertFalse(sub._handle_checkout_session({**session, 'customer': 'cus_other'}))

    def test_10_manage_billing_opens_portal(self):
        sub = self.sub_as_admin()
        sub.action_start_subscription()
        action = sub.action_manage_billing()
        self.assertEqual(action['url'], 'https://billing.stripe.com/p/session/test_1')

    def test_11_security_other_company_and_non_admin(self):
        self.sub_as_admin().action_start_subscription()
        # admin of Zeta cannot read/manage Acme's subscription (record rule)
        with self.assertRaises(AccessError):
            self.subscription.with_user(self.other_admin).with_company(self.other_company).read(['stripe_customer_id'])
        with self.assertRaises(AccessError):
            self.subscription.with_user(self.other_admin).action_cancel()
        # a normal team member cannot open the billing page
        with self.assertRaises(AccessError):
            self.env['bharatplus.subscription'].with_user(self.member).with_company(self.company).action_open_my_subscription()
        # the Acme admin sees only Acme
        visible = self.env['bharatplus.subscription'].with_user(self.admin).with_company(self.company).search([])
        self.assertEqual(visible, self.subscription)

    def test_12_settings_create_price_in_paise(self):
        settings = self.env['res.config.settings'].create({'bharatplus_stripe_secret_key': 'sk_test_dummy'})
        settings.action_bharatplus_create_stripe_price()
        price = self.fake.prices.create.call_args.kwargs['params']
        self.assertEqual(price['currency'], 'inr')
        self.assertEqual(price['unit_amount'], 40000, "₹400 = 40,000 paise")
        self.assertEqual(price['recurring'], {'interval': 'month'})
        self.assertEqual(self.env['ir.config_parameter'].sudo().get_param('bharatplus_subscription.stripe_price_id'), 'price_test_1')

    def test_13_cron_reconciles_quantity_drift(self):
        self.sub_as_admin().action_start_subscription()
        self.fake.quantity = 5   # drift on the Stripe side
        self.env['bharatplus.subscription']._cron_reconcile()
        self.assertEqual(self.fake.quantity, 2)
        self.assertEqual(self.subscription.quantity, 2)

    def test_14_new_company_gets_draft_subscription(self):
        company = self.env['res.company'].create({'name': 'New Co'})
        self.assertEqual(company.subscription_id.state, 'draft')
