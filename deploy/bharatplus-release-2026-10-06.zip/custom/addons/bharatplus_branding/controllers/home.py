from odoo import http
from odoo.http import request
from odoo.addons.web.controllers.home import Home as WebHome

OLD_PREFIX = '/odoo'
NEW_PREFIX = '/crm'


class Home(WebHome):

    @http.route(['/web', '/odoo', '/odoo/<path:subpath>', '/scoped_app/<path:subpath>',
                 '/crm', '/crm/<path:subpath>'])
    def web_client(self, s_action=None, **kw):
        """Serve the web client under /crm and permanently redirect the old /odoo URLs."""
        path = request.httprequest.path
        if path == OLD_PREFIX or path.startswith(OLD_PREFIX + '/'):
            query = request.httprequest.query_string.decode()
            new_url = NEW_PREFIX + path[len(OLD_PREFIX):] + ('?' + query if query else '')
            return request.redirect(new_url, code=301)
        return super().web_client(s_action=s_action, **kw)
