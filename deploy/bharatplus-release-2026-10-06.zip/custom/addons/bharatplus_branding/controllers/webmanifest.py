from odoo import http
from odoo.http import request
from odoo.addons.web.controllers import webmanifest


class WebManifest(webmanifest.WebManifest):

    def _get_webmanifest(self):
        manifest = super()._get_webmanifest()
        manifest['scope'] = '/crm'
        manifest['start_url'] = '/crm'
        for shortcut in manifest.get('shortcuts', []):
            if shortcut.get('url', '').startswith('/odoo'):
                shortcut['url'] = '/crm' + shortcut['url'][5:]
        # Brand colour used by the installed web app (PWA) splash screen / title bar
        manifest['background_color'] = '#1E2952'
        manifest['theme_color'] = '#1E2952'
        return manifest

    @http.route()
    def service_worker(self):
        response = super().service_worker()
        response.headers['Service-Worker-Allowed'] = '/crm'
        return response

    @http.route(['/odoo/offline', '/crm/offline'])
    def offline(self):
        return super().offline()
