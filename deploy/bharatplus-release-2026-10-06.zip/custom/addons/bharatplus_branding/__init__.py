import base64

from odoo.tools import file_open

from . import rebrand
from . import controllers
from . import models


def _read_b64(path):
    with file_open(path, 'rb') as f:
        return base64.b64encode(f.read())


def post_init_hook(env):
    """Install-time only: set the company logo/favicon (never overwritten on upgrade)."""
    companies = env['res.company'].sudo().search([])
    # Company logo (login page, navbar/appsbar and PDF report header)
    companies.write({'logo': _read_b64('bharatplus_branding/static/src/img/logo.png')})
    # Company favicon (field added by muk_web_theme, only if that module is installed)
    if 'favicon' in env['res.company']._fields:
        companies.write({'favicon': _read_b64('bharatplus_branding/static/src/img/favicon.ico')})
    env['bharatplus.branding'].apply_branding()
