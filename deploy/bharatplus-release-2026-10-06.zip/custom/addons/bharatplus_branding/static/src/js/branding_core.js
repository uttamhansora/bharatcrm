import { _t, translatedTermsGlobal } from "@web/core/l10n/translation";
import { patch } from "@web/core/utils/patch";
import { registry } from "@web/core/registry";
import { Dialog } from "@web/core/dialog/dialog";
import { titleService } from "@web/core/browser/title_service";
import {
    ErrorDialog,
    ClientErrorDialog,
    NetworkErrorDialog,
    RPCErrorDialog,
    WarningDialog,
    RedirectWarningDialog,
} from "@web/core/errors/error_dialogs";

export const BRAND = "Bharatplus";
const ODOO_RE = /\bOdoo(Bot)?\b/g;

/** Replace the word "Odoo" (and "OdooBot") in a user-visible string. */
export function rebrand(text) {
    return text ? String(text).replace(ODOO_RE, `${BRAND}$1`) : text;
}

// ---------------------------------------------------------------------------
// Global hook: every translatable term (_t(...) in JS and static text in OWL
// templates) is looked up in `translatedTermsGlobal`. Terms that are not
// translated fall through to this prototype, which rebrands them on the fly.
// ---------------------------------------------------------------------------
const EXPLICIT_TERMS = {
    "Odoo Enterprise": "Premium features",
    "Get this feature and much more with Odoo Enterprise!": "This feature is not included in your edition.",
    "My Odoo.com Account": "My Account",
};
Object.setPrototypeOf(
    translatedTermsGlobal,
    new Proxy(Object.create(null), {
        get(_target, key) {
            if (typeof key !== "string") {
                return undefined;
            }
            if (key in EXPLICIT_TERMS) {
                return EXPLICIT_TERMS[key];
            }
            return key.includes("Odoo") ? rebrand(key) : undefined;
        },
    })
);

// Default dialog title
Dialog.defaultProps = { ...Dialog.defaultProps, title: BRAND };

// Error dialog titles
ErrorDialog.title = _t("Bharatplus Error");
ClientErrorDialog.title = _t("Bharatplus Client Error");
NetworkErrorDialog.title = _t("Bharatplus Network Error");

for (const DialogClass of [RPCErrorDialog, WarningDialog, RedirectWarningDialog]) {
    patch(DialogClass.prototype, {
        setup() {
            super.setup();
            this.title = rebrand(this.title);
        },
    });
}

// Browser tab title: the title service falls back to "Odoo" when no part is set
patch(titleService, {
    start(env) {
        const service = super.start(env);
        const fix = () => {
            if (/^(\(\d+\) )?Odoo$/.test(document.title)) {
                document.title = document.title.replace("Odoo", BRAND);
            }
        };
        const { setParts, setCounters } = service;
        service.setParts = (...args) => {
            setParts(...args);
            fix();
        };
        service.setCounters = (...args) => {
            setCounters(...args);
            fix();
        };
        fix();
        return service;
    },
});

// Session-expired notification shown on public pages
const sessionExpired = {
    title: _t("Bharatplus Session Expired"),
    message: _t("Your Bharatplus session expired. The current page is about to be refreshed."),
    buttons: [
        {
            text: _t("Ok"),
            click: () => window.location.reload(true),
            close: true,
        },
    ],
};
registry
    .category("error_notifications")
    .add("odoo.http.SessionExpiredException", sessionExpired, { force: true })
    .add("werkzeug.exceptions.Forbidden", sessionExpired, { force: true });
