import { registry } from "@web/core/registry";

// Remove the user-menu entries that link to odoo.com
const userMenu = registry.category("user_menuitems");
for (const item of ["documentation", "support", "odoo_account"]) {
    if (userMenu.contains(item)) {
        userMenu.remove(item);
    }
}
