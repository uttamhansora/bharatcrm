from odoo import api, models

from ..rebrand import BRAND, rebrand


class BharatplusBranding(models.AbstractModel):
    _name = 'bharatplus.branding'
    _description = 'Bharatplus branding helpers'

    @api.model
    def _rebrand_records(self, model, field_names):
        """Replace "Odoo" in the given text fields of every record of ``model``."""
        if model not in self.env:
            return
        for record in self.env[model].sudo().search([]):
            vals = {}
            for field_name in field_names:
                value = record[field_name] or ''
                new_value = rebrand(value)
                if new_value != value:
                    vals[field_name] = new_value.replace('www.odoo.com', 'www.bharatplus.co')
            if vals:
                record.write(vals)

    @api.model
    def apply_branding(self):
        """Rebrand records created by standard modules. Idempotent; runs on
        every install/upgrade of this module (see data/branding_data.xml)."""
        self.env['ir.config_parameter'].sudo().set_param('web.web_app_name', BRAND)
        self._rebrand_records('res.partner', ['name'])            # OdooBot -> BharatplusBot
        self._rebrand_records('res.groups', ['name'])             # "Receive notifications in Odoo"
        self._rebrand_records('mail.template', ['subject', 'body_html'])
        self._rebrand_records('digest.digest', ['name'])
        self._rebrand_records('digest.tip', ['name', 'tip_description'])
        return True
