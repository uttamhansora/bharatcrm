"""Server-side rebranding of translated strings.

Every string that goes through Odoo's translation machinery (``_()``,
``self.env._()``, lazy ``_lt()``) has the word "Odoo" replaced by the brand
name before it reaches the user. This covers error messages, chatbot replies,
notifications and other Python-side texts without touching core code.
"""
import re

from markupsafe import Markup

from odoo.orm import environments as _environments
from odoo.tools import translate as _translate

BRAND = 'Bharatplus'
_ODOO_RE = re.compile(r'\bOdoo(Bot)?\b')


def rebrand(text):
    if isinstance(text, str) and 'Odoo' in text:
        new_text = _ODOO_RE.sub(lambda m: BRAND + (m.group(1) or ''), text)
        return Markup(new_text) if isinstance(text, Markup) else new_text
    return text


_original_get_translation = _translate.get_translation


def _get_translation(module, lang, source, args):
    return rebrand(_original_get_translation(module, lang, source, args))


# Both modules look the function up in their own namespace at call time.
_translate.get_translation = _get_translation
_environments.get_translation = _get_translation
