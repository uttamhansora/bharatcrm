{
    'name': 'Bharatplus Branding',
    'version': '19.0.1.1.0',
    'summary': 'White-label: show the Bharatplus name and logo instead of Odoo',
    'description': """
Replaces the visible Odoo branding (window title, login page, error dialogs,
email footers, portal footer, reports, PWA manifest, company logo/favicon,
Apps page, settings texts) with Bharatplus branding, serves the web client
under /crm instead of /odoo, and rebrands translated strings globally.
""",
    'author': 'Bharatplus',
    'website': 'https://www.bharatplus.co',
    'license': 'LGPL-3',
    'category': 'Hidden/Tools',
    'depends': ['web', 'mail', 'portal', 'auth_signup', 'base_setup', 'iap', 'crm'],
    'data': [
        'views/templates.xml',
        'views/apps.xml',
        'views/settings.xml',
        'data/branding_data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'bharatplus_branding/static/src/js/branding_core.js',
            'bharatplus_branding/static/src/js/branding_backend.js',
            'bharatplus_branding/static/src/xml/branding_core.xml',
            'bharatplus_branding/static/src/xml/branding_backend.xml',
            'bharatplus_branding/static/src/css/backend.css',
        ],
        'web.assets_frontend': [
            'bharatplus_branding/static/src/js/branding_core.js',
            'bharatplus_branding/static/src/xml/branding_core.xml',
        ],
    },
    'post_init_hook': 'post_init_hook',
    'installable': True,
    'application': False,
    'auto_install': False,
}
