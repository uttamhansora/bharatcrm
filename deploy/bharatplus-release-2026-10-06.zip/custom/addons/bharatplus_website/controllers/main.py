import logging

from dateutil.relativedelta import relativedelta

from odoo import fields, http
from odoo.exceptions import UserError
from odoo.http import request
from odoo.addons.web.controllers.home import Home as WebHome
from odoo.addons.bharatplus_subscription.models.subscription import DEFAULT_UNIT_AMOUNT, TRIAL_MONTHS

_logger = logging.getLogger(__name__)

# Subscription states in which a customer must not start another subscription
RUNNING_STATES = ('trialing', 'active', 'past_due', 'unpaid', 'paused', 'incomplete')
BILLING_PAGE = '/crm/action-bharatplus_subscription.action_open_subscription'
PRICING_EXAMPLES = (1, 2, 5, 10)


def _page_values(page):
    """Values shared by every public page (header/footer)."""
    return {
        'page': page,
        'is_logged_in': bool(request.session.uid),
        'company': request.env.company.sudo(),
    }


def _pricing_values():
    """Pricing page context. The amounts here are for DISPLAY only: the real
    quantity is always recomputed server-side from the company's users."""
    values = _page_values('pricing')
    user = request.env.user
    is_internal = bool(request.session.uid) and not user.share
    subscription = None
    if is_internal:
        subscription = request.env['bharatplus.subscription'].sudo()._get_for_company(user.company_id, create=False)
    values.update({
        'unit_amount': int(DEFAULT_UNIT_AMOUNT),
        'trial_months': TRIAL_MONTHS,
        'examples': [(n, n * int(DEFAULT_UNIT_AMOUNT)) for n in PRICING_EXAMPLES],
        'is_internal': is_internal,
        'is_portal': bool(request.session.uid) and user.share,
        'is_admin': is_internal and user._is_bharatplus_manager(),
        'has_running_subscription': bool(subscription and subscription.state in RUNNING_STATES),
        'subscription': subscription,
        'billing_page': BILLING_PAGE,
        'meta_description': (
            "BharatPlus CRM pricing: start with a 1-month free trial, then pay ₹%d per active "
            "team member per month. Add or remove team members anytime." % int(DEFAULT_UNIT_AMOUNT)),
    })
    return values


class Home(WebHome):

    @http.route('/', type='http', auth='public')
    def index(self, s_action=None, db=None, **kw):
        """Serve the public home page instead of redirecting to the backend."""
        return request.render('bharatplus_website.home', _page_values('home'))


class BharatplusWebsite(http.Controller):

    @http.route('/home', type='http', auth='public')
    def home(self, **kw):
        return request.render('bharatplus_website.home', _page_values('home'))

    @http.route('/about', type='http', auth='public')
    def about(self, **kw):
        return request.render('bharatplus_website.about', _page_values('about'))

    @http.route('/contact', type='http', auth='public')
    def contact(self, **kw):
        return request.render('bharatplus_website.contact', _page_values('contact'))

    @http.route('/contact/submit', type='http', auth='public', methods=['POST'])
    def contact_submit(self, name='', email='', phone='', subject='', message='', website_url='', **kw):
        """Create a CRM opportunity from the contact form."""
        values = _page_values('contact')
        values.update({'name': name, 'email': email, 'phone': phone,
                       'subject': subject, 'message': message})
        # "website_url" is a hidden honeypot field: real visitors leave it empty
        if website_url:
            return request.render('bharatplus_website.contact_thanks', values)

        name = (name or '').strip()
        email = (email or '').strip()
        if not name or not email or not (message or '').strip():
            values['error'] = 'Please fill in your name, email and message.'
            return request.render('bharatplus_website.contact', values)

        lead_vals = {
            'name': (subject or '').strip() or 'Website enquiry from %s' % name,
            'type': 'opportunity',
            'contact_name': name,
            'email_from': email,
            'phone': (phone or '').strip() or False,
            'description': message,
        }
        try:
            request.env['crm.lead'].sudo().create(lead_vals)
        except Exception:
            _logger.exception('Could not create lead from the contact form')
            values['error'] = 'Sorry, something went wrong. Please try again or email us directly.'
            return request.render('bharatplus_website.contact', values)
        return request.render('bharatplus_website.contact_thanks', values)

    # ------------------------------------------------------------------
    # Pricing & free trial
    # ------------------------------------------------------------------
    @http.route('/pricing', type='http', auth='public')
    def pricing(self, **kw):
        return request.render('bharatplus_website.pricing', _pricing_values())

    @http.route('/pricing/start', type='http', auth='public', methods=['GET', 'POST'])
    def pricing_start(self, **kw):
        """Start Free Trial.

        Guest            -> existing signup flow, then back here.
        Portal user      -> explain that a CRM workspace is needed (contact us).
        Team member      -> explain that an administrator manages billing.
        Admin, running   -> existing billing page (never a duplicate subscription).
        Admin, no sub    -> GET: confirmation page; POST: create the Stripe
                            subscription (quantity = real member count, 1 month trial).
        """
        if not request.session.uid:
            return request.redirect('/web/signup?redirect=%2Fpricing%2Fstart')
        values = _pricing_values()
        if values['is_portal']:
            return request.render('bharatplus_website.pricing_message', {**values, 'reason': 'portal'})
        if not values['is_admin']:
            return request.render('bharatplus_website.pricing_message', {**values, 'reason': 'member'})
        if values['has_running_subscription']:
            return request.redirect(BILLING_PAGE)

        # act as the logged-in admin (access rights and company checks apply)
        subscription = request.env['bharatplus.subscription']._get_for_company(request.env.user.company_id)
        subscription = subscription.with_env(request.env)
        values.update({
            'subscription': subscription,
            'member_count': subscription.member_count,
            'monthly_amount': max(subscription.member_count, 1) * int(DEFAULT_UNIT_AMOUNT),
            'trial_end_preview': fields.Date.context_today(subscription) + relativedelta(months=TRIAL_MONTHS),
        })
        if not subscription.is_stripe_configured:
            return request.render('bharatplus_website.pricing_message', {**values, 'reason': 'unconfigured'})
        if request.httprequest.method == 'POST':
            try:
                subscription.action_start_subscription()
            except UserError as e:
                values['error'] = e.args[0] if e.args else str(e)
                return request.render('bharatplus_website.pricing_start', values)
            return request.redirect('/pricing/started')
        return request.render('bharatplus_website.pricing_start', values)

    @http.route('/pricing/started', type='http', auth='user')
    def pricing_started(self, **kw):
        values = _pricing_values()
        if not values['is_admin'] or not values['subscription']:
            return request.redirect('/pricing')
        return request.render('bharatplus_website.pricing_started', values)

    @http.route('/pricing/payment-method', type='http', auth='user', methods=['POST'])
    def pricing_payment_method(self, **kw):
        """Send the admin to Stripe Checkout (setup mode) to add a card."""
        values = _pricing_values()
        if not values['is_admin'] or not values['subscription']:
            return request.redirect('/pricing')
        subscription = values['subscription'].with_env(request.env)
        try:
            action = subscription.action_add_payment_method()
        except UserError as e:
            return request.render('bharatplus_website.pricing_message', {
                **values, 'reason': 'error', 'error': e.args[0] if e.args else str(e)})
        return request.redirect(action['url'], local=False)
