/* Pricing calculator: DISPLAY ONLY.
 * The real billed quantity is computed server-side from the company's active
 * team members; nothing entered here is ever sent to the server. */
(function () {
    "use strict";

    function init() {
        const calc = document.querySelector(".bp_calc");
        if (!calc) {
            return;
        }
        const unitAmount = parseInt(calc.dataset.unitAmount, 10) || 0;
        const input = calc.querySelector(".bp_calc_input");
        const amount = calc.querySelector(".bp_calc_amount");
        const membersLabel = calc.querySelector(".bp_calc_members_label");
        const min = parseInt(input.min, 10) || 1;
        const max = parseInt(input.max, 10) || 999;

        function clamp(value) {
            if (isNaN(value)) {
                return min;
            }
            return Math.min(max, Math.max(min, value));
        }

        function render() {
            const members = clamp(parseInt(input.value, 10));
            input.value = members;
            amount.textContent = (members * unitAmount).toLocaleString("en-IN");
            membersLabel.textContent = members + (members === 1 ? " member" : " members");
        }

        calc.querySelectorAll(".bp_calc_btn").forEach(function (button) {
            button.addEventListener("click", function () {
                const current = clamp(parseInt(input.value, 10));
                input.value = button.dataset.action === "inc" ? current + 1 : current - 1;
                render();
            });
        });
        input.addEventListener("input", render);
        input.addEventListener("change", render);
        render();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
