import re
from unittest.mock import MagicMock, patch

from odoo.tests import HttpCase, tagged

from odoo.addons.bharatplus_subscription.tests.common import FakeStripe, PARAM

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')


@tagged('post_install', '-at_install', 'bharatplus_website')
class TestPricingPage(HttpCase):

    def setUp(self):
        super().setUp()
        ICP = self.env['ir.config_parameter'].sudo()
        ICP.set_param(PARAM + 'stripe_secret_key', 'sk_test_dummy')
        ICP.set_param(PARAM + 'stripe_price_id', 'price_test_1')
        self.fake = FakeStripe()
        client = MagicMock()
        client.v1 = self.fake
        patcher = patch('odoo.addons.bharatplus_subscription.models.stripe_client.stripe.StripeClient', return_value=client)
        patcher.start()
        self.addCleanup(patcher.stop)

        self.company = self.env['res.company'].create({'name': 'Acme Traders'})
        groups = [self.env.ref('base.group_user').id, self.env.ref('base.group_system').id]
        self.admin = self.env['res.users'].with_context(no_reset_password=True).create({
            'name': 'Acme Admin', 'login': 'acme_admin', 'password': 'acme_admin_pw_123',
            'company_id': self.company.id, 'company_ids': [(6, 0, [self.company.id])],
            'group_ids': [(6, 0, groups)],
        })
        self.member = self.env['res.users'].with_context(no_reset_password=True).create({
            'name': 'Acme Member', 'login': 'acme_member', 'password': 'acme_member_pw_123',
            'company_id': self.company.id, 'company_ids': [(6, 0, [self.company.id])],
            'group_ids': [(6, 0, [self.env.ref('base.group_user').id])],
        })
        self.subscription = self.env['bharatplus.subscription']._get_for_company(self.company)

    def test_01_public_pricing_page(self):
        response = self.url_open('/pricing')
        self.assertEqual(response.status_code, 200)
        html = response.text
        self.assertIn('BharatPlus CRM Pricing', html)
        self.assertIn('Pricing | BharatplusCRM', html)
        self.assertIn('name="description"', html)
        self.assertIn('₹400', html)
        self.assertIn('₹2,000 / month', html)
        self.assertIn('₹4,000 / month', html)
        self.assertIn('Start Free Trial', html)
        self.assertNotIn('Manage Subscription', html)
        self.assertIn('data-unit-amount="400"', html)

    def test_02_guest_start_goes_to_signup(self):
        response = self.url_open('/pricing/start', allow_redirects=False)
        self.assertIn(response.status_code, (302, 303))
        self.assertIn('/web/signup', response.headers['Location'])
        self.assertIn('pricing', response.headers['Location'])
        # a POST without a session must not create anything either (CSRF check rejects it, or we redirect)
        response = self.url_open('/pricing/start', data={'csrf_token': 'x'}, allow_redirects=False)
        self.assertIn(response.status_code, (302, 303, 400))
        self.assertFalse(self.subscription.stripe_subscription_id)

    def test_03_admin_start_trial_end_to_end(self):
        self.authenticate('acme_admin', 'acme_admin_pw_123')
        # confirmation page shows the real member count (admin + member = 2)
        response = self.url_open('/pricing/start')
        self.assertEqual(response.status_code, 200)
        self.assertIn('Start my free trial', response.text)
        self.assertIn('₹400 × 2 = ₹800 / month', response.text)
        csrf_token = CSRF_RE.search(response.text).group(1)
        # POST creates the Stripe subscription with quantity = 2 and a trial
        response = self.url_open('/pricing/start', data={'csrf_token': csrf_token}, allow_redirects=False)
        self.assertIn(response.status_code, (302, 303), response.text[:300])
        self.assertIn('/pricing/started', response.headers['Location'])
        params = self.fake.subscriptions.create.call_args.kwargs['params']
        self.assertEqual(params['items'][0]['quantity'], 2)
        self.assertIn('trial_end', params)
        self.subscription.invalidate_recordset()
        self.assertEqual(self.subscription.state, 'trialing')
        self.assertEqual(self.subscription.quantity, 2)
        # subscribed customer now sees "Manage Subscription", and cannot start twice
        html = self.url_open('/pricing').text
        self.assertIn('Manage Subscription', html)
        self.assertNotIn('Start Free Trial', html)
        response = self.url_open('/pricing/start', allow_redirects=False)
        self.assertIn(response.status_code, (302, 303))
        self.assertIn('bharatplus_subscription.action_open_subscription', response.headers['Location'])
        self.fake.subscriptions.create.assert_called_once()
        # thank-you page and the "Add payment method" hand-off to Stripe Checkout
        html = self.url_open('/pricing/started').text
        self.assertIn('Your free trial has started', html)
        csrf_token = CSRF_RE.search(html).group(1)
        response = self.url_open('/pricing/payment-method', data={'csrf_token': csrf_token}, allow_redirects=False)
        self.assertIn(response.status_code, (302, 303))
        self.assertIn('checkout.stripe.com', response.headers['Location'])

    def test_04_member_cannot_start_trial(self):
        self.authenticate('acme_member', 'acme_member_pw_123')
        response = self.url_open('/pricing/start')
        self.assertEqual(response.status_code, 200)
        self.assertIn('Ask your administrator', response.text)
        self.assertFalse(self.subscription.stripe_subscription_id)
