{
    'name': 'BharatplusCRM Website Pages',
    'version': '19.0.1.1.0',
    'summary': 'Public Home, About, Pricing and Contact Us pages with a Login button',
    'description': """
Public pages for BharatplusCRM served by the same Odoo server:

* /            Home page
* /about       About page
* /pricing     Pricing page with member calculator and "Start Free Trial"
               (connected to the real Stripe subscription of the company)
* /contact     Contact Us page (the form creates a CRM opportunity)

The header shows a Login button that opens the CRM login page.
""",
    'author': 'Bharatplus',
    'website': 'https://www.bharatplus.co',
    'license': 'LGPL-3',
    'category': 'Website',
    'depends': ['web', 'crm', 'bharatplus_branding', 'bharatplus_subscription'],
    'data': [
        'views/templates.xml',
        'views/pricing_templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'bharatplus_website/static/src/css/website.css',
            'bharatplus_website/static/src/js/pricing.js',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
